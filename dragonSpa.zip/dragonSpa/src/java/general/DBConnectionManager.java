/*
 * DBConnectionManager.java
 * 
 * Created on Sep 3, 2007, 1:12:24 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package general;

import java.sql.Connection;
import com.ownx.db.GeneralException;
import com.ownx.db.SQLConnectionManager;
import com.ownx.db.SQLConnectionParameter;

/**
 *
 * @author nsdan2k
 */
public class DBConnectionManager {

    public DBConnectionManager() {
    }

    public Connection getConnection() throws GeneralException {
        SQLConnectionParameter info=new SQLConnectionParameter("mysql","dragonspa","localhost","root","password");
        SQLConnectionManager mgr=new SQLConnectionManager(info);
        return mgr.getConnection();
    }
    
}
