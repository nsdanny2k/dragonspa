/*
 * PostalAddress.java
 * 
 * Created on Sep 3, 2007, 12:54:13 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.GregorianCalendar;

/**
 *
 * @author nsdan2k
 */
public class PostalAddress {

    public PostalAddress() {
    }
    private String id;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String zip;
    private String partyId;

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }
    
    public boolean updateAddress(String purpose, String partyId, String address1, String address2, String city, String state, String zip, Connection c) {
        int count2=0;
        String id2="";
        String sql="";
        Statement s;
        ResultSet r;
        SQLHelper h=new SQLHelper();

        int count;
        try {
            
            
            String sql2="SELECT * FROM party_contact_mech_purpose WHERE PARTY_ID=\""+partyId+"\" AND CONTACT_MECH_PURPOSE_TYPE_ID=\""+purpose+"\"";
            Statement s2=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r2=s2.executeQuery(sql2);

            Timestamp x2=new Timestamp(System.currentTimeMillis());
            Date x1=new java.sql.Date((new GregorianCalendar(2001, 0, 1)).getTime().getTime());
            while (r2.next()) {
                id2=r2.getString("CONTACT_MECH_ID");
                
                if (address1.equals("") && address2.equals("")) {
                    
                    sql="DELETE FROM postal_address WHERE CONTACT_MECH_ID="+id2;
                    s=c.createStatement();
                    count=s.executeUpdate(sql);   
                    
                    sql="DELETE FROM party_contact_mech WHERE CONTACT_MECH_ID="+id2;
                    s=c.createStatement();
                    count=s.executeUpdate(sql);   

                    r2.deleteRow();

                    sql="DELETE FROM contact_mech WHERE CONTACT_MECH_ID="+id2;
                    s=c.createStatement();
                    count=s.executeUpdate(sql);   
                
                } else {
                    
                    String sql3="SELECT * FROM postal_address WHERE CONTACT_MECH_ID="+id2;
                    Statement s3=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                    ResultSet r3=s3.executeQuery(sql3);
                    while (r3.next()) {
                        if (!address1.equals("")) {
                            r3.updateString("ADDRESS1", address1 );
                        }
                        if (!address2.equals("")) {
                            r3.updateString("ADDRESS2", address2 );
                        }
                        if (!city.equals("")) {
                            r3.updateString("CITY", city );
                        }
                        if (!state.equals("")) {
                            r3.updateString("STATE_PROVINCE_GEO_ID", state );
                        }
                        if (!zip.equals("")) {
                            r3.updateString("POSTAL_CODE", zip );
                        }
                        r3.updateTimestamp("LAST_UPDATED_STAMP", x2);
                        r3.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                        r3.updateRow();
                        break;
                    }
                }
                count2 = count2 + 1;
            }
            
            if (count2 < 1) {
                if (!(address1.equals("") && address2.equals(""))) {

                    sql="SELECT * FROM contact_mech";
                    s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                    r=s.executeQuery(sql);
                    r.moveToInsertRow();
                    String desc=address1+" "+address2+" "+city+" "+state+" "+zip;
                    r.updateString("CONTACT_MECH_TYPE_ID","POSTAL_ADDRESS");
                    r.updateString("INFO_STRING", desc);
                    r.updateTimestamp("CREATED_STAMP", x2);
                    r.updateTimestamp("CREATED_TX_STAMP", x2);
                    r.updateTimestamp("LAST_UPDATED_STAMP", x2);
                    r.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                    h.insertAutoKey("contact_mech", "CONTACT_MECH_ID", r, c);

                    sql="SELECT * FROM contact_mech WHERE INFO_STRING = \""+desc+"\"";
                    s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                    r=s.executeQuery(sql);
                    while (r.next()) {
                        id2=r.getString("CONTACT_MECH_ID");

                        sql="UPDATE contact_mech SET INFO_STRING=null WHERE CONTACT_MECH_ID="+id2;
                        s=c.createStatement();
                        count=s.executeUpdate(sql);     
                        
                        String sql4="SELECT * FROM postal_address";
                        Statement s4=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                        ResultSet r4=s4.executeQuery(sql4);  
                        r4.moveToInsertRow();
                        r4.updateString("CONTACT_MECH_ID", id2);
                        if (!address1.equals("")) {
                            r4.updateString("ADDRESS1", address1 );
                        }
                        if (!address2.equals("")) {
                            r4.updateString("ADDRESS2", address2 );
                        }
                        if (!city.equals("")) {
                            r4.updateString("CITY", city );
                        }
                        if (!state.equals("")) {
                            r4.updateString("STATE_PROVINCE_GEO_ID", state );
                        }
                        if (!zip.equals("")) {
                            r4.updateString("POSTAL_CODE", zip );
                        }
                        r4.updateTimestamp("CREATED_STAMP", x2);
                        r4.updateTimestamp("CREATED_TX_STAMP", x2);
                        r4.updateTimestamp("LAST_UPDATED_STAMP", x2);
                        r4.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                        r4.insertRow();
                        
                        sql4="SELECT * FROM party_contact_mech";
                        s4=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                        r4=s4.executeQuery(sql4);  
                        r4.moveToInsertRow();
                        r4.updateString("PARTY_ID", partyId);
                        r4.updateString("CONTACT_MECH_ID", id2);
                        r4.updateDate("FROM_DATE", x1);
                        r4.updateTimestamp("CREATED_STAMP", x2);
                        r4.updateTimestamp("CREATED_TX_STAMP", x2);
                        r4.updateTimestamp("LAST_UPDATED_STAMP", x2);
                        r4.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                        r4.insertRow();
                        
                        r2.moveToInsertRow();
                        r2.updateString("PARTY_ID", partyId);
                        r2.updateString("CONTACT_MECH_ID", id2);
                        r2.updateString("CONTACT_MECH_PURPOSE_TYPE_ID",purpose);
                        r2.updateDate("FROM_DATE", x1);
                        r2.updateTimestamp("CREATED_STAMP", x2);
                        r2.updateTimestamp("CREATED_TX_STAMP", x2);
                        r2.updateTimestamp("LAST_UPDATED_STAMP", x2);
                        r2.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                        r2.insertRow();
                    
                        break;
                    }
                }
            }        
            return true;
             
            
        } catch (Exception e) {
            return false;
        } 
        
    }    
}
