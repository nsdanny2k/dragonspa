
/*
 * Ledger.java
 * 
 * Created on Sep 14, 2007, 1:14:29 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

/**
 *
 * @author nsdan2k
 */
public class LedgerDetail {

    public LedgerDetail() {
    }
    private int id;
    private Date transDate;
    private String patientId;
    private int insuranceProviderId;
    private int treatmentId;
    private String status;
    private String type;
    private double amount;
    private String checkNumber;
    private Date checkDate;
    private String bankName;
    private String authNumber;
    private String cardType;
    private String remarks;
    private String accountId;
    private String errMessage;

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAuthNumber() {
        return authNumber;
    }

    public void setAuthNumber(String authNumber) {
        this.authNumber = authNumber;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public Date getCheckDate() {
        return checkDate;
    }

    public void setCheckDate(Date checkDate) {
        this.checkDate = checkDate;
    }

    public String getCheckNumber() {
        return checkNumber;
    }

    public void setCheckNumber(String checkNumber) {
        this.checkNumber = checkNumber;
    }

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getInsuranceProviderId() {
        return insuranceProviderId;
    }

    public void setInsuranceProviderId(int insuranceProviderId) {
        this.insuranceProviderId = insuranceProviderId;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getTransDate() {
        return transDate;
    }

    public void setTransDate(Date transDate) {
        this.transDate = transDate;
    }

    public int getTreatmentId() {
        return treatmentId;
    }

    public void setTreatmentId(int treatmentId) {
        this.treatmentId = treatmentId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean fetch(int id) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();

            String sql="SELECT * FROM ledger WHERE ID="+id;
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            while (r.next()) {
                this.setId(id);
                this.setTreatmentId(r.getInt("TREATMENT_ID"));
                this.setTransDate((java.util.Date)r.getDate("TRANS_DATE"));
                this.setPatientId(r.getString("PATIENT_ID"));
                this.setInsuranceProviderId(r.getInt("INSURANCE_PROVIDER_ID"));
                this.setStatus(r.getString("STATUS"));
                this.setType(r.getString("TYPE"));
                this.setAmount(r.getDouble("AMOUNT"));
                this.setCheckNumber(r.getString("CHECK_NUMBER"));
                this.setCheckDate((java.util.Date)r.getDate("CHECK_DATE"));
                this.setBankName(r.getString("BANK_NAME"));
                this.setAuthNumber(r.getString("AUTH_NUMBER"));
                this.setCardType(r.getString("CARD_TYPE"));
                this.setRemarks(r.getString("REMARKS"));
                this.setAccountId(r.getString("ACCOUNT_ID"));
                retval= true;
            }
            return retval;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }            
    }
    
    public boolean add() {
        this.setErrMessage("");
        WebController ctr=new WebController();
            this.setId(id);
            this.setTreatmentId(0);
            this.setTransDate(null);
            this.setPatientId("");
            this.setInsuranceProviderId(0);
            this.setStatus("");
            this.setType("Cash");
            this.setAmount(0);
            this.setCheckNumber("");
            this.setCheckDate(null);
            this.setBankName("");
            this.setAuthNumber("");
            this.setCardType("");
            this.setRemarks("");
            this.setAccountId("");
                
        return true;
    }
    
    public boolean delete(int id) {
        return false;
    }
    
    public boolean save() {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql;
            Statement s;
            ResultSet r;
            boolean ok;
            if (this.getId()==0) {
                sql="SELECT * FROM ledger";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                r.moveToInsertRow();
                ok=true;
            } else {
                sql="SELECT * FROM ledger WHERE ID="+this.getId()+"";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                ok=r.next();
            }
            if (ok) {
                r.updateInt("TREATMENT_ID",this.getTreatmentId());
                r.updateDate("TRANS_DATE",new java.sql.Date(this.getTransDate().getTime()));
                r.updateString("PATIENT_ID",this.getPatientId());
                r.updateInt("INSURANCE_PROVIDER_ID",this.getInsuranceProviderId());
                r.updateString("STATUS",this.getStatus());
                r.updateString("TYPE",this.getType());
                r.updateDouble("AMOUNT",this.getAmount());
                r.updateString("CHECK_NUMBER",this.getCheckNumber());
                if (this.getCheckDate()!=null) {
                    r.updateDate("CHECK_DATE",new java.sql.Date(this.getCheckDate().getTime()));
                }
                r.updateString("BANK_NAME",this.getBankName());
                r.updateString("AUTH_NUMBER",this.getAuthNumber());
                r.updateString("CARD_TYPE",this.getCardType());
                r.updateString("REMARKS",this.getRemarks());
                r.updateString("ACCOUNT_ID", this.getAccountId());
                
                if (this.getId()==0) {
                    r.insertRow();
                } else {
                    r.updateRow();
                }
                int tId=r.getInt("TREATMENT_ID");
                if (this.calcPayment(tId)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false; //not ok
            }
            
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }
    }                    
    
    public boolean calcPayment(int id) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql5="SELECT * FROM treatment_entry WHERE TREATMENT_ID="+id+" ORDER BY ID DESC";
            Statement s5=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r5=s5.executeQuery(sql5);                    
            if (r5.next()) {
                double d=0;
                String sql4="SELECT SUM(AMOUNT) AS SUM_AMOUNT FROM ledger WHERE TREATMENT_ID="+id+" GROUP BY TREATMENT_ID";
                Statement s4=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                ResultSet r4=s4.executeQuery(sql4);                    
                while (r4.next()) {
                    d=r4.getDouble("SUM_AMOUNT");
                }
                r5.updateDouble("PAID", d);
                r5.updateRow();
            }                
            model.TreatmentDetail detail=new model.TreatmentDetail();
            detail.calcBalance(this.getTreatmentId());        
            return true;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }
    }
    
}
