/*
 * Country.java
 * 
 * Created on Sep 9, 2007, 12:59:20 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

/**
 *
 * @author nsdan2k
 */
public class Country {

    public Country() {
    }

    private String code;
    private String description;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
}
