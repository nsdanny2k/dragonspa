/*
 * Person.java
 * 
 * Created on Sep 3, 2007, 12:48:46 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author nsdan2k
 */
public class Person {

    public Person() {
    }
    
    private String firstName;
    private String middleName;
    private String lastName;
    private Date birthDate;
    private String gender;
    private String maritalStatus;
    private String ssn;

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }
    
    public boolean save() {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();

            SQLHelper h=new SQLHelper();
            String sql="SELECT * FROM party";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            r.moveToInsertRow();
            r.updateString("PARTY_TYPE_ID", "PERSON");
            String desc=this.getFirstName()+" "+this.getLastName();
            r.updateString("DESCRIPTION", desc);
            h.insertAutoKey("party", "PARTY_ID", r, c);

            sql="SELECT * FROM party WHERE Description = \""+desc+"\"";
            s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            r=s.executeQuery(sql);
            while (r.next()) {
                String id=r.getString("PARTY_ID");

                sql="UPDATE party SET Description=null WHERE PARTY_ID="+id;
                s=c.createStatement();
                int count=s.executeUpdate(sql);       

                sql="SELECT * FROM person";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                r.moveToInsertRow();
                r.updateString("PARTY_ID",id);
                r.updateString("FIRST_NAME", this.getFirstName());
                r.updateString("MIDDLE_NAME", (this.getMiddleName().equals(""))?null:this.getMiddleName());
                r.updateString("LAST_NAME", this.getLastName());
                r.updateDate("BIRTH_DATE",(this.getBirthDate().equals(ctr.BLANKDATE()))?null:new java.sql.Date(this.getBirthDate().getTime()));
                r.updateString("GENDER", (this.getGender().equals(""))?null:this.getGender());
                r.updateString("MARITAL_STATUS", (this.getMaritalStatus().equals(""))?null:this.getMaritalStatus());
                r.updateString("SOCIAL_SECURITY_NUMBER",(this.getSsn().equals(""))?null:this.getSsn());
                Timestamp x=new Timestamp(System.currentTimeMillis());
                r.updateTimestamp("CREATED_STAMP", x);
                r.updateTimestamp("CREATED_TX_STAMP", x);
                r.updateTimestamp("LAST_UPDATED_STAMP", x);
                r.updateTimestamp("LAST_UPDATED_TX_STAMP", x);
                r.insertRow();
                /*
                Attribute attrib=new Attribute("party_attribute","PARTY_ID");
                attrib.updateAttribute(id, "ReferredBy", this.getReferredBy(), c);
                attrib.updateAttribute(id, "Student", this.getStudent(), c);
                attrib.updateAttribute(id, "Occupation", this.getOccupation(), c);
                attrib.updateAttribute(id, "Employer", this.getEmployer(), c);
                attrib.updateAttribute(id, "HeadOfHousehold", this.getHeadOfHousehold(), c);
                attrib.updateAttribute(id, "Relation", this.getRelation(), c);
                attrib.updateAttribute(id, "Provider", this.getProvider(), c);
                attrib.updateAttribute(id, "ProviderPlan", this.getProviderPlan(), c);
                TelecomNumber tel=new TelecomNumber();
                tel.updateNumber("PHONE_MOBILE", id, "", "", this.getMobileNumber(), c);
                tel.updateNumber("PHONE_HOME", id, "", "", this.getHomePhoneNumber(), c);
                tel.updateNumber("PHONE_WORK", id, "", "", this.getOfficePhoneNumber(), c);
                PostalAddress addr=new PostalAddress();
                addr.updateAddress("PRIMARY_LOCATION", id, this.getHomeAddress1(), this.getHomeAddress2(), this.getHomeCity(), this.getHomeState(), this.getHomeZip(), c);
                addr.updateAddress("WORK_LOCATION", id, this.getOfficeAddress1(), this.getOfficeAddress2(), this.getOfficeCity(), this.getOfficeState(), this.getOfficeZip(), c);
                 */
                break;
            }
            return true;
        } catch (Exception e) {
            return false;
        }        
    }
    

}
