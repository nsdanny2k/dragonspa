/*
 * LedgerDetails.java
 * 
 * Created on Sep 14, 2007, 1:22:56 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Vector;

/**
 *
 * @author nsdan2k
 */
public class LedgerDetails extends Vector {

    public LedgerDetails() {
    }
    private int sets;

    public int getSets() {
        return sets;
    }
    
    public int fetch(Date transDate, String account, int from, int count) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.LedgerDetail detail;
        try {
            int i=0;
            int j=0;
            Connection c=db.getConnection();
            String sql="SELECT * FROM ledger WHERE TRANS_DATE=\'"+ctr.convertDateToSQLString(transDate)+"\' AND ACCOUNT_ID=\'"+account+"\' ORDER BY ID";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {

                i=i+1;
                if ((i<(from-1)*(count)+1))  {
                    //skip
                } else {
                    j=j+1;
                    if (j<=count) {
                        detail=new model.LedgerDetail();
                        detail.fetch(r.getInt("ID"));
                        this.add(detail);
                    }
                }
                
            }
            this.sets=i/count;
            if((i % count)>0) {
                this.sets=this.sets+1;
            }    
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }

    public int fetch(Date transDateFrom, Date transDateTo, String account) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.LedgerDetail detail;
        try {
            int i=0;
            Connection c=db.getConnection();
            String sql="SELECT * FROM ledger WHERE TRANS_DATE>=\'"+ctr.convertDateToSQLString(transDateFrom)+"\' AND  TRANS_DATE<=\'"+ctr.convertDateToSQLString(transDateTo)+"\' AND ACCOUNT_ID=\'"+account+"\' ORDER BY ID";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {

                i=i+1;

                detail=new model.LedgerDetail();
                detail.fetch(r.getInt("ID"));
                this.add(detail);

                
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }

    public double getTotal(Date transDateFrom, Date transDateTo, String account) {
        double i=0;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.LedgerDetail detail;
        try {
            Connection c=db.getConnection();
            String sql="SELECT SUM(AMOUNT) AS SUM_AMOUNT FROM ledger WHERE TRANS_DATE>=\'"+ctr.convertDateToSQLString(transDateFrom)+"\' AND  TRANS_DATE<=\'"+ctr.convertDateToSQLString(transDateTo)+"\' AND ACCOUNT_ID=\'"+account+"\' GROUP BY ACCOUNT_ID";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            if (r.next()) {
                i=r.getDouble("SUM_AMOUNT");
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }      
}
