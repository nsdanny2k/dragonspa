/*
 * Treatment.java
 * 
 * Created on Sep 7, 2007, 1:39:23 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.Date;

/**
 *
 * @author nsdan2k
 */
public class Treatment {

    public Treatment() {
        this.setErrMessage("");
    }

    private String dentalUnit;
    private String doctorId;
    private String doctor;
    private String patientId;
    private String patient;
    private String accountId;
    private String treatmentId;
    private Date dateVisit;
    private Date lastVisit;
    private String controlNumber;
    private String errMessage;
    private String diagnosis;
    private String treatment;
    private String remarks;
    private Timestamp time_from;
    private Timestamp time_to;
    private String T1;
    private String T2;
    private String T3;
    private String T4;
    private String T5;
    private String T6;
    private String T7;
    private String T8;
    private String T9;
    private String T10;
    private String T11;
    private String T12;
    private String T13;
    private String T14;
    private String T15;
    private String T16;
    private String T17;
    private String T18;
    private String T19;
    private String T20;
    private String T21;
    private String T22;
    private String T23;
    private String T24;
    private String T25;
    private String T26;
    private String T27;
    private String T28;
    private String T29;
    private String T30;
    private String T31;
    private String T32;
    private String TA;
    private String TB;
    private String TC;
    private String TD;
    private String TE;
    private String TF;
    private String TG;
    private String TH;
    private String TI;
    private String TJ;
    private String TK;
    private String TL;
    private String TM;
    private String TN;
    private String TO;
    private String TP;
    private String TQ;
    private String TR;
    private String TS;
    private String TT;
    private String U1;
    private String U2;
    private String U3;
    private String U4;
    private String U5;
    private String U6;
    private String U7;
    private String U8;
    private String U9;
    private String U10;
    private String U11;
    private String U12;
    private String U13;
    private String U14;
    private String U15;
    private String U16;
    private String U17;
    private String U18;
    private String U19;
    private String U20;
    private String U21;
    private String U22;
    private String U23;
    private String U24;
    private String U25;
    private String U26;
    private String U27;
    private String U28;
    private String U29;
    private String U30;
    private String U31;
    private String U32;
    private String UA;
    private String UB;
    private String UC;
    private String UD;
    private String UE;
    private String UF;
    private String UG;
    private String UH;
    private String UI;
    private String UJ;
    private String UK;
    private String UL;
    private String UM;
    private String UN;
    private String UO;
    private String UP;
    private String UQ;
    private String UR;
    private String US;
    private String UT;

    public Timestamp getTime_from() {
        return time_from;
    }

    public void setTime_from(Timestamp time_from) {
        this.time_from = time_from;
    }

    public Timestamp getTime_to() {
        return time_to;
    }

    public void setTime_to(Timestamp time_to) {
        this.time_to = time_to;
    }

    public String getT1() {
        return T1;
    }

    public void setT1(String T1) {
        this.T1 = T1;
    }

    public String getT10() {
        return T10;
    }

    public void setT10(String T10) {
        this.T10 = T10;
    }

    public String getT11() {
        return T11;
    }

    public void setT11(String T11) {
        this.T11 = T11;
    }

    public String getT12() {
        return T12;
    }

    public void setT12(String T12) {
        this.T12 = T12;
    }

    public String getT13() {
        return T13;
    }

    public void setT13(String T13) {
        this.T13 = T13;
    }

    public String getT14() {
        return T14;
    }

    public void setT14(String T14) {
        this.T14 = T14;
    }

    public String getT15() {
        return T15;
    }

    public void setT15(String T15) {
        this.T15 = T15;
    }

    public String getT16() {
        return T16;
    }

    public void setT16(String T16) {
        this.T16 = T16;
    }

    public String getT17() {
        return T17;
    }

    public void setT17(String T17) {
        this.T17 = T17;
    }

    public String getT18() {
        return T18;
    }

    public void setT18(String T18) {
        this.T18 = T18;
    }

    public String getT19() {
        return T19;
    }

    public void setT19(String T19) {
        this.T19 = T19;
    }

    public String getT2() {
        return T2;
    }

    public void setT2(String T2) {
        this.T2 = T2;
    }

    public String getT20() {
        return T20;
    }

    public void setT20(String T20) {
        this.T20 = T20;
    }

    public String getT21() {
        return T21;
    }

    public void setT21(String T21) {
        this.T21 = T21;
    }

    public String getT22() {
        return T22;
    }

    public void setT22(String T22) {
        this.T22 = T22;
    }

    public String getT23() {
        return T23;
    }

    public void setT23(String T23) {
        this.T23 = T23;
    }

    public String getT24() {
        return T24;
    }

    public void setT24(String T24) {
        this.T24 = T24;
    }

    public String getT25() {
        return T25;
    }

    public void setT25(String T25) {
        this.T25 = T25;
    }

    public String getT26() {
        return T26;
    }

    public void setT26(String T26) {
        this.T26 = T26;
    }

    public String getT27() {
        return T27;
    }

    public void setT27(String T27) {
        this.T27 = T27;
    }

    public String getT28() {
        return T28;
    }

    public void setT28(String T28) {
        this.T28 = T28;
    }

    public String getT29() {
        return T29;
    }

    public void setT29(String T29) {
        this.T29 = T29;
    }

    public String getT3() {
        return T3;
    }

    public void setT3(String T3) {
        this.T3 = T3;
    }

    public String getT30() {
        return T30;
    }

    public void setT30(String T30) {
        this.T30 = T30;
    }

    public String getT31() {
        return T31;
    }

    public void setT31(String T31) {
        this.T31 = T31;
    }

    public String getT32() {
        return T32;
    }

    public void setT32(String T32) {
        this.T32 = T32;
    }

    public String getT4() {
        return T4;
    }

    public void setT4(String T4) {
        this.T4 = T4;
    }

    public String getT5() {
        return T5;
    }

    public void setT5(String T5) {
        this.T5 = T5;
    }

    public String getT6() {
        return T6;
    }

    public void setT6(String T6) {
        this.T6 = T6;
    }

    public String getT7() {
        return T7;
    }

    public void setT7(String T7) {
        this.T7 = T7;
    }

    public String getT8() {
        return T8;
    }

    public void setT8(String T8) {
        this.T8 = T8;
    }

    public String getT9() {
        return T9;
    }

    public void setT9(String T9) {
        this.T9 = T9;
    }

    public String getTA() {
        return TA;
    }

    public void setTA(String TA) {
        this.TA = TA;
    }

    public String getTB() {
        return TB;
    }

    public void setTB(String TB) {
        this.TB = TB;
    }

    public String getTC() {
        return TC;
    }

    public void setTC(String TC) {
        this.TC = TC;
    }

    public String getTD() {
        return TD;
    }

    public void setTD(String TD) {
        this.TD = TD;
    }

    public String getTE() {
        return TE;
    }

    public void setTE(String TE) {
        this.TE = TE;
    }

    public String getTF() {
        return TF;
    }

    public void setTF(String TF) {
        this.TF = TF;
    }

    public String getTG() {
        return TG;
    }

    public void setTG(String TG) {
        this.TG = TG;
    }

    public String getTH() {
        return TH;
    }

    public void setTH(String TH) {
        this.TH = TH;
    }

    public String getTI() {
        return TI;
    }

    public void setTI(String TI) {
        this.TI = TI;
    }

    public String getTJ() {
        return TJ;
    }

    public void setTJ(String TJ) {
        this.TJ = TJ;
    }

    public String getTK() {
        return TK;
    }

    public void setTK(String TK) {
        this.TK = TK;
    }

    public String getTL() {
        return TL;
    }

    public void setTL(String TL) {
        this.TL = TL;
    }

    public String getTM() {
        return TM;
    }

    public void setTM(String TM) {
        this.TM = TM;
    }

    public String getTN() {
        return TN;
    }

    public void setTN(String TN) {
        this.TN = TN;
    }

    public String getTO() {
        return TO;
    }

    public void setTO(String TO) {
        this.TO = TO;
    }

    public String getTP() {
        return TP;
    }

    public void setTP(String TP) {
        this.TP = TP;
    }

    public String getTQ() {
        return TQ;
    }

    public void setTQ(String TQ) {
        this.TQ = TQ;
    }

    public String getTR() {
        return TR;
    }

    public void setTR(String TR) {
        this.TR = TR;
    }

    public String getTS() {
        return TS;
    }

    public void setTS(String TS) {
        this.TS = TS;
    }

    public String getTT() {
        return TT;
    }

    public void setTT(String TT) {
        this.TT = TT;
    }

    public String getU1() {
        return U1;
    }

    public void setU1(String U1) {
        this.U1 = U1;
    }

    public String getU10() {
        return U10;
    }

    public void setU10(String U10) {
        this.U10 = U10;
    }

    public String getU11() {
        return U11;
    }

    public void setU11(String U11) {
        this.U11 = U11;
    }

    public String getU12() {
        return U12;
    }

    public void setU12(String U12) {
        this.U12 = U12;
    }

    public String getU13() {
        return U13;
    }

    public void setU13(String U13) {
        this.U13 = U13;
    }

    public String getU14() {
        return U14;
    }

    public void setU14(String U14) {
        this.U14 = U14;
    }

    public String getU15() {
        return U15;
    }

    public void setU15(String U15) {
        this.U15 = U15;
    }

    public String getU16() {
        return U16;
    }

    public void setU16(String U16) {
        this.U16 = U16;
    }

    public String getU17() {
        return U17;
    }

    public void setU17(String U17) {
        this.U17 = U17;
    }

    public String getU18() {
        return U18;
    }

    public void setU18(String U18) {
        this.U18 = U18;
    }

    public String getU19() {
        return U19;
    }

    public void setU19(String U19) {
        this.U19 = U19;
    }

    public String getU2() {
        return U2;
    }

    public void setU2(String U2) {
        this.U2 = U2;
    }

    public String getU20() {
        return U20;
    }

    public void setU20(String U20) {
        this.U20 = U20;
    }

    public String getU21() {
        return U21;
    }

    public void setU21(String U21) {
        this.U21 = U21;
    }

    public String getU22() {
        return U22;
    }

    public void setU22(String U22) {
        this.U22 = U22;
    }

    public String getU23() {
        return U23;
    }

    public void setU23(String U23) {
        this.U23 = U23;
    }

    public String getU24() {
        return U24;
    }

    public void setU24(String U24) {
        this.U24 = U24;
    }

    public String getU25() {
        return U25;
    }

    public void setU25(String U25) {
        this.U25 = U25;
    }

    public String getU26() {
        return U26;
    }

    public void setU26(String U26) {
        this.U26 = U26;
    }

    public String getU27() {
        return U27;
    }

    public void setU27(String U27) {
        this.U27 = U27;
    }

    public String getU28() {
        return U28;
    }

    public void setU28(String U28) {
        this.U28 = U28;
    }

    public String getU29() {
        return U29;
    }

    public void setU29(String U29) {
        this.U29 = U29;
    }

    public String getU3() {
        return U3;
    }

    public void setU3(String U3) {
        this.U3 = U3;
    }

    public String getU30() {
        return U30;
    }

    public void setU30(String U30) {
        this.U30 = U30;
    }

    public String getU31() {
        return U31;
    }

    public void setU31(String U31) {
        this.U31 = U31;
    }

    public String getU32() {
        return U32;
    }

    public void setU32(String U32) {
        this.U32 = U32;
    }

    public String getU4() {
        return U4;
    }

    public void setU4(String U4) {
        this.U4 = U4;
    }

    public String getU5() {
        return U5;
    }

    public void setU5(String U5) {
        this.U5 = U5;
    }

    public String getU6() {
        return U6;
    }

    public void setU6(String U6) {
        this.U6 = U6;
    }

    public String getU7() {
        return U7;
    }

    public void setU7(String U7) {
        this.U7 = U7;
    }

    public String getU8() {
        return U8;
    }

    public void setU8(String U8) {
        this.U8 = U8;
    }

    public String getU9() {
        return U9;
    }

    public void setU9(String U9) {
        this.U9 = U9;
    }

    public String getUA() {
        return UA;
    }

    public void setUA(String UA) {
        this.UA = UA;
    }

    public String getUB() {
        return UB;
    }

    public void setUB(String UB) {
        this.UB = UB;
    }

    public String getUC() {
        return UC;
    }

    public void setUC(String UC) {
        this.UC = UC;
    }

    public String getUD() {
        return UD;
    }

    public void setUD(String UD) {
        this.UD = UD;
    }

    public String getUE() {
        return UE;
    }

    public void setUE(String UE) {
        this.UE = UE;
    }

    public String getUF() {
        return UF;
    }

    public void setUF(String UF) {
        this.UF = UF;
    }

    public String getUG() {
        return UG;
    }

    public void setUG(String UG) {
        this.UG = UG;
    }

    public String getUH() {
        return UH;
    }

    public void setUH(String UH) {
        this.UH = UH;
    }

    public String getUI() {
        return UI;
    }

    public void setUI(String UI) {
        this.UI = UI;
    }

    public String getUJ() {
        return UJ;
    }

    public void setUJ(String UJ) {
        this.UJ = UJ;
    }

    public String getUK() {
        return UK;
    }

    public void setUK(String UK) {
        this.UK = UK;
    }

    public String getUL() {
        return UL;
    }

    public void setUL(String UL) {
        this.UL = UL;
    }

    public String getUM() {
        return UM;
    }

    public void setUM(String UM) {
        this.UM = UM;
    }

    public String getUN() {
        return UN;
    }

    public void setUN(String UN) {
        this.UN = UN;
    }

    public String getUO() {
        return UO;
    }

    public void setUO(String UO) {
        this.UO = UO;
    }

    public String getUP() {
        return UP;
    }

    public void setUP(String UP) {
        this.UP = UP;
    }

    public String getUQ() {
        return UQ;
    }

    public void setUQ(String UQ) {
        this.UQ = UQ;
    }

    public String getUR() {
        return UR;
    }

    public void setUR(String UR) {
        this.UR = UR;
    }

    public String getUS() {
        return US;
    }

    public void setUS(String US) {
        this.US = US;
    }

    public String getUT() {
        return UT;
    }

    public void setUT(String UT) {
        this.UT = UT;
    }

    public Date getDateVisit() {
        return dateVisit;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getControlNumber() {
        return controlNumber;
    }

    public void setControlNumber(String controlNumber) {
        this.controlNumber = controlNumber;
    }

    public void setDateVisit(Date dateVisit) {
        this.dateVisit = dateVisit;
    }

    public Date getLastVisit() {
        return lastVisit;
    }

    public void setLastVisit(Date lastVisit) {
        this.lastVisit = lastVisit;
    }

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getDentalUnit() {
        return dentalUnit;
    }

    public void setDentalUnit(String dentalUnit) {
        this.dentalUnit = dentalUnit;
    }

    public String getDoctor() {
        return doctor;
    }

    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getPatient() {
        return patient;
    }

    public void setPatient(String patient) {
        this.patient = patient;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getTreatmentId() {
        return treatmentId;
    }

    public void setTreatmentId(String treatmentId) {
        this.treatmentId = treatmentId;
    }
    
    public int create() {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql;
            Statement s;
            ResultSet r;
            int retval=0;
            
            sql="SELECT * FROM treatment";
            s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            r=s.executeQuery(sql);
            r.moveToInsertRow();
            r.updateString("ACCOUNT_ID", this.getAccountId());
            r.updateString("DENTAL_UNIT", this.getDentalUnit());
            r.updateString("DOCTOR_ID", this.getDoctorId());
            model.Doctor doc=new model.Doctor();
            doc.fetch(this.getDoctorId(), this.getAccountId());
            r.updateString("DOCTOR", doc.getFirstName()+" "+doc.getLastName());
            r.updateString("PATIENT_ID", this.getPatientId());
            model.Patient pat=new model.Patient();
            pat.fetch(this.getPatientId(), this.getAccountId());
            r.updateString("PATIENT", pat.getFirstName()+" "+pat.getLastName());
            r.updateTimestamp("TIME_FROM", ctr.TIMESTAMP());
            r.updateDate("DATE_VISIT",new java.sql.Date(ctr.TODAY().getTime()));
            String sql2="SELECT * FROM treatment WHERE PATIENT_ID = \'" + this.getPatientId()+"\' AND ACCOUNT_ID = \'" + this.getAccountId()+ "\' ORDER BY DATE_VISIT DESC";
            Statement s2=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r2=s2.executeQuery(sql2);
            if (r2.next()) {
                r.updateDate("LAST_VISIT", r2.getDate("DATE_VISIT"));
            } else {
                r.updateDate("LAST_VISIT",new java.sql.Date(ctr.TODAY().getTime()));
            }
            sql2="SELECT * FROM treatment WHERE ACCOUNT_ID = \'" + this.getAccountId()+ "\' ORDER BY CONTROL_NUMBER DESC";
            s2=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            r2=s2.executeQuery(sql2);
            if (r2.next()) {
                try {
                    String newkey="";
                    String keyval=r2.getString("CONTROL_NUMBER");
                    double d=Double.valueOf(keyval).doubleValue();
                    DecimalFormat nf = new DecimalFormat("###");
                    newkey=nf.format(d+1);
                    r.updateString("CONTROL_NUMBER", newkey);
                }
                catch (java.lang.NumberFormatException e) {
                }                 
            } else {
                r.updateString("CONTROL_NUMBER", "10000");
            }
            String t=ctr.convertTimeStampToString(ctr.TIMESTAMP());
            r.updateString("REMARKS", t);
            Timestamp x=new Timestamp(System.currentTimeMillis());
            r.updateTimestamp("CREATED_STAMP", x);
            r.updateTimestamp("LAST_UPDATED_STAMP", x);            
            r.insertRow();
            sql="SELECT * FROM treatment WHERE REMARKS = \'"+t+"\'";
            s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            r=s.executeQuery(sql);
            while (r.next()) {
                retval=r.getInt("TREATMENT_ID");
            }
            return retval;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return 0;
        }                
    }


    public boolean fetch(String id, String account) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();

            String sql="SELECT * FROM treatment WHERE TREATMENT_ID=\""+id+"\" AND ACCOUNT_ID=\""+account+"\"";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            while (r.next()) {
                this.setTreatmentId(id);
                this.setDentalUnit(r.getString("DENTAL_UNIT"));
                this.setDoctorId(r.getString("DOCTOR_ID"));
                this.setDoctor(r.getString("DOCTOR"));
                this.setPatientId(r.getString("PATIENT_ID"));
                this.setPatient(r.getString("PATIENT"));
                this.setAccountId(r.getString("ACCOUNT_ID")); 
                this.setDateVisit((java.util.Date)r.getDate("DATE_VISIT"));
                this.setLastVisit((java.util.Date)r.getDate("LAST_VISIT"));
                this.setControlNumber(r.getString("CONTROL_NUMBER"));
                this.setTreatment(r.getString("TREATMENT"));
                this.setDiagnosis(r.getString("DIAGNOSIS"));
                this.setRemarks(r.getString("REMARKS"));
                this.setT1(r.getString("T1"));
                this.setT2(r.getString("T2"));
                this.setT3(r.getString("T3"));
                this.setT4(r.getString("T4"));
                this.setT5(r.getString("T5"));
                this.setT6(r.getString("T6"));
                this.setT7(r.getString("T7"));
                this.setT8(r.getString("T8"));
                this.setT9(r.getString("T9"));
                this.setT10(r.getString("T10"));
                this.setT11(r.getString("T11"));
                this.setT12(r.getString("T12"));
                this.setT13(r.getString("T13"));
                this.setT14(r.getString("T14"));
                this.setT15(r.getString("T15"));
                this.setT16(r.getString("T16"));
                this.setT17(r.getString("T17"));
                this.setT18(r.getString("T18"));
                this.setT19(r.getString("T19"));
                this.setT20(r.getString("T20"));
                this.setT21(r.getString("T21"));
                this.setT22(r.getString("T22"));
                this.setT23(r.getString("T23"));
                this.setT24(r.getString("T24"));
                this.setT25(r.getString("T25"));
                this.setT26(r.getString("T26"));
                this.setT27(r.getString("T27"));
                this.setT28(r.getString("T28"));
                this.setT29(r.getString("T29"));
                this.setT30(r.getString("T30"));
                this.setT31(r.getString("T31"));
                this.setT32(r.getString("T32"));
                this.setTA(r.getString("TA"));
                this.setTB(r.getString("TB"));
                this.setTC(r.getString("TC"));
                this.setTD(r.getString("TD"));
                this.setTE(r.getString("TE"));
                this.setTF(r.getString("TF"));
                this.setTG(r.getString("TG"));
                this.setTH(r.getString("TH"));
                this.setTI(r.getString("TI"));
                this.setTJ(r.getString("TJ"));
                this.setTK(r.getString("TK"));
                this.setTL(r.getString("TL"));
                this.setTM(r.getString("TM"));
                this.setTN(r.getString("TN"));
                this.setTO(r.getString("TO"));
                this.setTP(r.getString("TP"));
                this.setTQ(r.getString("TQ"));
                this.setTR(r.getString("TR"));
                this.setTS(r.getString("TS"));
                this.setTT(r.getString("TT"));
                this.setU1(r.getString("U1"));
                this.setU2(r.getString("U2"));
                this.setU3(r.getString("U3"));
                this.setU4(r.getString("U4"));
                this.setU5(r.getString("U5"));
                this.setU6(r.getString("U6"));
                this.setU7(r.getString("U7"));
                this.setU8(r.getString("U8"));
                this.setU9(r.getString("U9"));
                this.setU10(r.getString("U10"));
                this.setU11(r.getString("U11"));
                this.setU12(r.getString("U12"));
                this.setU13(r.getString("U13"));
                this.setU14(r.getString("U14"));
                this.setU15(r.getString("U15"));
                this.setU16(r.getString("U16"));
                this.setU17(r.getString("U17"));
                this.setU18(r.getString("U18"));
                this.setU19(r.getString("U19"));
                this.setU20(r.getString("U20"));
                this.setU21(r.getString("U21"));
                this.setU22(r.getString("U22"));
                this.setU23(r.getString("U23"));
                this.setU24(r.getString("U24"));
                this.setU25(r.getString("U25"));
                this.setU26(r.getString("U26"));
                this.setU27(r.getString("U27"));
                this.setU28(r.getString("U28"));
                this.setU29(r.getString("U29"));
                this.setU30(r.getString("U30"));
                this.setU31(r.getString("U31"));
                this.setU32(r.getString("U32"));
                this.setUA(r.getString("UA"));
                this.setUB(r.getString("UB"));
                this.setUC(r.getString("UC"));
                this.setUD(r.getString("UD"));
                this.setUE(r.getString("UE"));
                this.setUF(r.getString("UF"));
                this.setUG(r.getString("UG"));
                this.setUH(r.getString("UH"));
                this.setUI(r.getString("UI"));
                this.setUJ(r.getString("UJ"));
                this.setUK(r.getString("UK"));
                this.setUL(r.getString("UL"));
                this.setUM(r.getString("UM"));
                this.setUN(r.getString("UN"));
                this.setUO(r.getString("UO"));
                this.setUP(r.getString("UP"));
                this.setUQ(r.getString("UQ"));
                this.setUR(r.getString("UR"));
                this.setUS(r.getString("US"));
                this.setUT(r.getString("UT"));                
                retval= true;
            }
            return retval;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }            
    }
    
    public boolean delete() {
        this.setErrMessage("");
        return false;
    }
    
    public boolean save() {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql;
            Statement s;
            ResultSet r;
            boolean ok;
            if (this.getTreatmentId().equals("")) {
                sql="SELECT * FROM treatement";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                r.moveToInsertRow();
                ok=true;
            } else {
                sql="SELECT * FROM treatment WHERE TREATMENT_ID=\""+this.getTreatmentId()+"\"";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                ok=r.next();
            }
            if (ok) {
                /*
                r.updateString("DENTAL_UNIT",this.getDentalUnit());
                 */
                r.updateString("DOCTOR_ID",this.getDoctorId());
                r.updateString("DOCTOR",this.getDoctor());
                /*
                r.updateString("PATIENT_ID",this.getPatientId());
                r.updateString("PATIENT",this.getPatient());
                r.updateString("ACCOUNT_ID",this.getAccountId()); 
                r.updateDate("DATE_VISIT",(this.getDateVisit().equals(ctr.BLANKDATE()))?null:new java.sql.Date(this.getDateVisit().getTime()));
                r.updateDate("LAST_VISIT",(this.getLastVisit().equals(ctr.BLANKDATE()))?null:new java.sql.Date(this.getLastVisit().getTime()));
                r.updateString("CONTROL_NUMBER",this.getControlNumber());
                r.updateString("ACCOUNT_ID", this.getAccountId());
                */
                r.updateString("T1",this.getT1());
                r.updateString("T2",this.getT2());
                r.updateString("T3",this.getT3());
                r.updateString("T4",this.getT4());
                r.updateString("T5",this.getT5());
                r.updateString("T6",this.getT6());
                r.updateString("T7",this.getT7());
                r.updateString("T8",this.getT8());
                r.updateString("T9",this.getT9());
                r.updateString("T10",this.getT10());
                r.updateString("T11",this.getT11());
                r.updateString("T12",this.getT12());
                r.updateString("T13",this.getT13());
                r.updateString("T14",this.getT14());
                r.updateString("T15",this.getT15());
                r.updateString("T16",this.getT16());
                r.updateString("T17",this.getT17());
                r.updateString("T18",this.getT18());
                r.updateString("T19",this.getT19());
                r.updateString("T20",this.getT20());
                r.updateString("T21",this.getT21());
                r.updateString("T22",this.getT22());
                r.updateString("T23",this.getT23());
                r.updateString("T24",this.getT24());
                r.updateString("T25",this.getT25());
                r.updateString("T26",this.getT26());
                r.updateString("T27",this.getT27());
                r.updateString("T28",this.getT28());
                r.updateString("T29",this.getT29());
                r.updateString("T30",this.getT30());
                r.updateString("T31",this.getT31());
                r.updateString("T32",this.getT32());
                r.updateString("TA",this.getTA());
                r.updateString("TB",this.getTB());
                r.updateString("TC",this.getTC());
                r.updateString("TD",this.getTD());
                r.updateString("TE",this.getTE());
                r.updateString("TF",this.getTF());
                r.updateString("TG",this.getTG());
                r.updateString("TH",this.getTH());
                r.updateString("TI",this.getTI());
                r.updateString("TJ",this.getTJ());
                r.updateString("TK",this.getTK());
                r.updateString("TL",this.getTL());
                r.updateString("TM",this.getTM());
                r.updateString("TN",this.getTN());
                r.updateString("TO",this.getTO());
                r.updateString("TP",this.getTP());
                r.updateString("TQ",this.getTQ());
                r.updateString("TR",this.getTR());
                r.updateString("TS",this.getTS());
                r.updateString("TT",this.getTT());
                r.updateString("U1",this.getU1());
                r.updateString("U2",this.getU2());
                r.updateString("U3",this.getU3());
                r.updateString("U4",this.getU4());
                r.updateString("U5",this.getU5());
                r.updateString("U6",this.getU6());
                r.updateString("U7",this.getU7());
                r.updateString("U8",this.getU8());
                r.updateString("U9",this.getU9());
                r.updateString("U10",this.getU10());
                r.updateString("U11",this.getU11());
                r.updateString("U12",this.getU12());
                r.updateString("U13",this.getU13());
                r.updateString("U14",this.getU14());
                r.updateString("U15",this.getU15());
                r.updateString("U16",this.getU16());
                r.updateString("U17",this.getU17());
                r.updateString("U18",this.getU18());
                r.updateString("U19",this.getU19());
                r.updateString("U20",this.getU20());
                r.updateString("U21",this.getU21());
                r.updateString("U22",this.getU22());
                r.updateString("U23",this.getU23());
                r.updateString("U24",this.getU24());
                r.updateString("U25",this.getU25());
                r.updateString("U26",this.getU26());
                r.updateString("U27",this.getU27());
                r.updateString("U28",this.getU28());
                r.updateString("U29",this.getU29());
                r.updateString("U30",this.getU30());
                r.updateString("U31",this.getU31());
                r.updateString("U32",this.getU32());
                r.updateString("UA",this.getUA());
                r.updateString("UB",this.getUB());
                r.updateString("UC",this.getUC());
                r.updateString("UD",this.getUD());
                r.updateString("UE",this.getUE());
                r.updateString("UF",this.getUF());
                r.updateString("UG",this.getUG());
                r.updateString("UH",this.getUH());
                r.updateString("UI",this.getUI());
                r.updateString("UJ",this.getUJ());
                r.updateString("UK",this.getUK());
                r.updateString("UL",this.getUL());
                r.updateString("UM",this.getUM());
                r.updateString("UN",this.getUN());
                r.updateString("UO",this.getUO());
                r.updateString("UP",this.getUP());
                r.updateString("UQ",this.getUQ());
                r.updateString("UR",this.getUR());
                r.updateString("US",this.getUS());
                r.updateString("UT",this.getUT());
                r.updateString("TREATMENT",this.getTreatment());
                r.updateString("DIAGNOSIS",this.getDiagnosis());
                r.updateString("REMARKS",this.getRemarks());
                if (this.getTreatmentId().equals("")) {
                    r.insertRow();
                } else {
                    r.updateRow();
                }
                return true;
            } else {
                return false; //not ok
            }
            
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }
    } 
    
   
    public boolean fetchLast(String patientId, String account) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();

            String sql="SELECT * FROM treatment WHERE PATIENT_ID = \'"+patientId+"\' ORDER BY TREATMENT_ID DESC";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            if (r.next()) {
                retval=this.fetch(r.getString("Treatment_ID"),account);
            }
            return retval;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }            
    }     
}
