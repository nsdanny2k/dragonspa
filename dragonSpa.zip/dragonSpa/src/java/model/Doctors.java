/*
 * Patients.java
 * 
 * Created on Sep 5, 2007, 2:18:09 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author nsdan2k
 */
public class Doctors extends Vector {

    public Doctors() {
    }
    
    public int fetch(String account) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.Doctor doctor;
        try {
            int i=0;
            Connection c=db.getConnection();
            String sql="SELECT * FROM doctor WHERE ACCOUNT_ID=\'"+account+"\' ORDER BY FIRST_NAME";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                i=i+1;
                doctor=new model.Doctor();
                doctor.setPartyId(r.getString("PARTY_ID"));
                doctor.setFirstName(r.getString("FIRST_NAME"));
                doctor.setMiddleName(r.getString("MIDDLE_NAME"));
                doctor.setLastName(r.getString("LAST_NAME"));
                this.add(doctor);
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }
    
    public String lookup(int id) {
        String retval="";
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            String sql="SELECT * FROM doctor WHERE PARTY_ID="+id;
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                retval=r.getString("FIRST_NAME")+" "+r.getString("LAST_NAME");
            }
            return retval;
        } catch (Exception e) {
            return "";        
        }      
    }      
}

