/*
 * TreatmentDetail.java
 * 
 * Created on Sep 10, 2007, 2:17:15 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

/**
 *
 * @author nsdan2k
 */
public class TreatmentDetail {

    public TreatmentDetail() {
        this.setErrMessage("");
    }
    
    private String tooth;
    private int diagnosisId;
    private String diagnosis;
    private int procedureId;
    private String procedure;
    private double charge;
    private double paid;
    private double balance;
    private String remarks;
    private double insCharge;
    private int treatmentId;
    private Date dateVisit;
    private int id;
    private String errMessage;

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    public Date getDateVisit() {
        return dateVisit;
    }

    public void setDateVisit(Date dateVisit) {
        this.dateVisit = dateVisit;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getCharge() {
        return charge;
    }

    public void setCharge(double charge) {
        this.charge = charge;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public int getDiagnosisId() {
        return diagnosisId;
    }

    public void setDiagnosisId(int diagnosisId) {
        this.diagnosisId = diagnosisId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getInsCharge() {
        return insCharge;
    }

    public void setInsCharge(double insCharge) {
        this.insCharge = insCharge;
    }

    public double getPaid() {
        return paid;
    }

    public void setPaid(double paid) {
        this.paid = paid;
    }

    public String getProcedure() {
        return procedure;
    }

    public void setProcedure(String procedure) {
        this.procedure = procedure;
    }

    public int getProcedureId() {
        return procedureId;
    }

    public void setProcedureId(int procedureId) {
        this.procedureId = procedureId;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getTooth() {
        return tooth;
    }

    public void setTooth(String tooth) {
        this.tooth = tooth;
    }

    public int getTreatmentId() {
        return treatmentId;
    }

    public void setTreatmentId(int treatmentId) {
        this.treatmentId = treatmentId;
    }
    

    public boolean fetch(int id) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();

            String sql="SELECT * FROM treatment_entry WHERE ID="+id;
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            while (r.next()) {
                this.setId(id);
                /*
                this.setTooth(r.getString("TOOTH"));
                this.setDiagnosisId(r.getInt("DIAGNOSIS_ID"));
                this.setDiagnosis(r.getString("DIAGNOSIS"));
                */
                this.setProcedureId(r.getInt("PROCEDURE_ID"));
                this.setProcedure(r.getString("PROCEDURE"));
                this.setCharge(r.getDouble("CHARGE"));
                this.setPaid(r.getDouble("PAID"));
                this.setBalance(r.getDouble("BALANCE"));
                this.setRemarks(r.getString("REMARKS"));
                this.setInsCharge(r.getDouble("INS_CHARGE"));
                this.setTreatmentId(r.getInt("TREATMENT_ID"));
             
                retval= true;
            }
            return retval;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }            
    }
    
    public boolean add() {
        this.setErrMessage("");
        WebController ctr=new WebController();
        this.setId(0);
        /*
        this.setTooth("");
        this.setDiagnosisId(0);
        this.setDiagnosis("");
        */
        this.setProcedureId(0);
        this.setProcedure("");
        this.setCharge(0);
        this.setPaid(0);
        this.setBalance(0);
        this.setRemarks("");
        this.setInsCharge(0);
        this.setTreatmentId(0);
                
        return true;
    }
    
    public boolean delete(int id) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();

            boolean ok;
            int tId=0;
            String sql2="SELECT * FROM treatment_entry WHERE ID="+id+"";
            Statement s2=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r2=s2.executeQuery(sql2);
            if (r2.next()) {
                tId=r2.getInt("TREATMENT_ID");
            }
                
            String sql="DELETE FROM treatment_entry WHERE ID="+id;
            Statement s=c.createStatement();
            int count=s.executeUpdate(sql);
            
            if (tId!=0) {
                this.calcBalance(tId);
            }
            return (count>0);
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }      
    }
    
    public boolean save() {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql;
            Statement s;
            ResultSet r;
            boolean ok;
            if (this.getId()==0) {
                sql="SELECT * FROM treatment_entry";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                r.moveToInsertRow();
                ok=true;
            } else {
                sql="SELECT * FROM treatment_entry WHERE ID="+this.getId()+"";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                ok=r.next();
            }
            if (ok) {
                /*
                r.updateString("TOOTH",this.getTooth());
                r.updateInt("DIAGNOSIS_ID",this.getDiagnosisId());
                r.updateString("DIAGNOSIS",this.getDiagnosis());
                */
                r.updateInt("PROCEDURE_ID",this.getProcedureId());
                r.updateString("PROCEDURE",this.getProcedure());
                r.updateDouble("CHARGE",this.getCharge());
                r.updateDouble("PAID",this.getPaid());
                r.updateDouble("BALANCE",this.getBalance());
                r.updateString("REMARKS",this.getRemarks());
                r.updateDouble("INS_CHARGE",this.getInsCharge());
                r.updateInt("TREATMENT_ID",this.getTreatmentId());
                
                if (this.getId()==0) {
                    r.insertRow();
                } else {
                    r.updateRow();
                }
                this.calcBalance(this.getTreatmentId());
                return true;
            } else {
                return false; //not ok
            }
            
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }
    }       
    
    public boolean calcBalance(int treatmentId) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql="SELECT * FROM treatment_entry WHERE TREATMENT_ID="+treatmentId+" ORDER BY ID ASC";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            int i=0;
            double bal=0;
            
            while (r.next()) {
                i=i+1;
                if (i==1) {
                    int tId=r.getInt("TREATMENT_ID");
                    String sql3="SELECT * FROM treatment WHERE TREATMENT_ID="+tId+"";
                    Statement s3=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                    ResultSet r3=s3.executeQuery(sql3);
                    if (r3.next()) {
                        String partyId=r3.getString("PATIENT_ID");
                        String sql4="SELECT * FROM treatment WHERE TREATMENT_ID<"+tId+" AND PATIENT_ID = \'"+partyId+"\' ORDER BY TREATMENT_ID DESC";
                        Statement s4=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                        ResultSet r4=s4.executeQuery(sql4);                    
                        while (r4.next()) {
                            boolean hasrec=false;
                            int tOId=r4.getInt("TREATMENT_ID");
                            String sql5="SELECT * FROM treatment_entry WHERE TREATMENT_ID="+tOId+" ORDER BY ID DESC";
                            Statement s5=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                            ResultSet r5=s5.executeQuery(sql5);                    
                            if (r5.next()) {
                                hasrec=true;
                                bal=r5.getDouble("BALANCE");
                            }
                            if (hasrec) {
                                break;
                            }
                        }
                        
                    }
                }

                
                bal=bal+r.getDouble("CHARGE")-r.getDouble("PAID");
                String sql2="SELECT * FROM treatment_entry WHERE ID="+r.getInt("ID")+"";
                Statement s2=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                ResultSet r2=s2.executeQuery(sql2);
                while (r2.next()) {
                    r2.updateDouble("BALANCE",bal);
                    r2.updateRow();
                }
            }
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }
        return false;
    }
    

}
