/*
 * InsuranceCodes.java
 * 
 * Created on Sep 9, 2007, 3:14:55 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author nsdan2k
 */
public class InsuranceCodes extends Vector {

    public InsuranceCodes() {
    }

     private int sets;

    public int getSets() {
        return sets;
    }
    
    public int fetch(String account, int from, int count) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.InsuranceCode code;
        try {
            int i=0;
            int j=0;
            Connection c=db.getConnection();
            String sql="SELECT * FROM insurancecode WHERE ACCOUNT_ID=\'"+account+"\' ORDER BY CODE";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {

                i=i+1;
                if ((i<(from-1)*(count)+1))  {
                    //skip
                } else {
                    j=j+1;
                    if (j<=count) {
                        code=new model.InsuranceCode();
                        code.setId(r.getInt("ID"));
                        code.setCode(r.getString("CODE"));
                        code.setDescription(r.getString("DESCRIPTION"));
                        code.setAccountId(r.getString("ACCOUNT_ID"));
                        this.add(code);
                    }
                }
                
            }
            this.sets=i/count;
            if((i % count)>0) {
                this.sets=this.sets+1;
            }    
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }
    
    
    public int fetch(String account) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.InsuranceCode code;
        try {
            int i=0;
            Connection c=db.getConnection();
            String sql="SELECT * FROM insurancecode WHERE ACCOUNT_ID=\'"+account+"\' ORDER BY CODE";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {

                i=i+1;
                code=new model.InsuranceCode();
                code.setId(r.getInt("ID"));
                code.setCode(r.getString("CODE"));
                code.setDescription(r.getString("DESCRIPTION"));
                code.setAccountId(r.getString("ACCOUNT_ID"));
                this.add(code);
                
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    } 
    
    public String lookupDescription(int id) {
        String retval="";
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            String sql="SELECT * FROM insurancecode WHERE ID="+id;
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                retval=r.getString("DESCRIPTION");
            }
            return retval;
        } catch (Exception e) {
            return "";        
        }      
    }    
}
