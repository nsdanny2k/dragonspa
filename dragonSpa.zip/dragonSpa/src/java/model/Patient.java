/*
 * Patient.java
 * 
 * Created on Sep 1, 2007, 9:49:24 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author nsdan2k
 */
public class Patient {

    public Patient() {
    }
    private String partyId;
    private String accountId;
    private String firstName;
    private String middleName;
    private String lastName;
    private Date birthDate;
    private String gender;
    private String maritalStatus;
    private String referredBy;
    private String student;
    private String emailAddress;
    private String mobileNumber;
    private String homePhoneNumber;
    private String officePhoneNumber;
    private String homeAddress1;
    private String homeAddress2;
    private String homeCity;
    private String homeState;
    private String homeZip;
    private String occupation;
    private String ssn;
    private String employer;
    private String officeAddress1;
    private String officeAddress2;
    private String officeCity;
    private String officeState;
    private String officeZip;
    private String headOfHousehold;
    private String relation;
    private String provider;
    private String providerPlan;

    public String getPartyId() {
        return partyId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }
    
    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getEmployer() {
        return employer;
    }

    public void setEmployer(String employer) {
        this.employer = employer;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHeadOfHousehold() {
        return headOfHousehold;
    }

    public void setHeadOfHousehold(String headOfHousehold) {
        this.headOfHousehold = headOfHousehold;
    }

    public String getHomeAddress1() {
        return homeAddress1;
    }

    public void setHomeAddress1(String homeAddress1) {
        this.homeAddress1 = homeAddress1;
    }

    public String getHomeAddress2() {
        return homeAddress2;
    }

    public void setHomeAddress2(String homeAddress2) {
        this.homeAddress2 = homeAddress2;
    }

    public String getHomeCity() {
        return homeCity;
    }

    public void setHomeCity(String homeCity) {
        this.homeCity = homeCity;
    }

    public String getHomePhoneNumber() {
        return homePhoneNumber;
    }

    public void setHomePhoneNumber(String homePhoneNumber) {
        this.homePhoneNumber = homePhoneNumber;
    }

    public String getHomeState() {
        return homeState;
    }

    public void setHomeState(String homeState) {
        this.homeState = homeState;
    }

    public String getHomeZip() {
        return homeZip;
    }

    public void setHomeZip(String homeZip) {
        this.homeZip = homeZip;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getOfficeAddress1() {
        return officeAddress1;
    }

    public void setOfficeAddress1(String officeAddress1) {
        this.officeAddress1 = officeAddress1;
    }

    public String getOfficeAddress2() {
        return officeAddress2;
    }

    public void setOfficeAddress2(String officeAddress2) {
        this.officeAddress2 = officeAddress2;
    }

    public String getOfficeCity() {
        return officeCity;
    }

    public void setOfficeCity(String officeCity) {
        this.officeCity = officeCity;
    }

    public String getOfficePhoneNumber() {
        return officePhoneNumber;
    }

    public void setOfficePhoneNumber(String officePhoneNumber) {
        this.officePhoneNumber = officePhoneNumber;
    }

    public String getOfficeState() {
        return officeState;
    }

    public void setOfficeState(String officeState) {
        this.officeState = officeState;
    }

    public String getOfficeZip() {
        return officeZip;
    }

    public void setOfficeZip(String officeZip) {
        this.officeZip = officeZip;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getProviderPlan() {
        return providerPlan;
    }

    public void setProviderPlan(String providerPlan) {
        this.providerPlan = providerPlan;
    }

    public String getReferredBy() {
        return referredBy;
    }

    public void setReferredBy(String referredBy) {
        this.referredBy = referredBy;
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getStudent() {
        return student;
    }

    public void setStudent(String student) {
        this.student = student;
    }
    
    public String getGenderDesc(String code) {
        if (code.equals("M")) {
            return "Male";
        } else if (code.equals("F")) {
            return "Female";
        } else {
            return "";
        }
    }
        
    public String getMaritalStatusDesc(String code) {
        if (code.equals("M")) {
            return "Married";
        } else if (code.equals("S")) {
            return "Single";
        } else if (code.equals("P")) {
            return "Seperated";
        } else if (code.equals("D")) {
            return "Divorced";
        } else if (code.equals("W")) {
            return "Widowed";
        } else {
            return "";
        }
    }
    public boolean search(String name) {
        return false;
    }
    
    public boolean fetch(String id, String account) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();

            SQLHelper h=new SQLHelper();

            String sql="SELECT * FROM patient WHERE PARTY_ID=\""+id+"\" AND ACCOUNT_ID=\""+account+"\"";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            while (r.next()) {
                this.setPartyId(r.getString("PARTY_ID"));
                this.setFirstName(r.getString("FIRST_NAME"));
                this.setMiddleName(r.getString("MIDDLE_NAME"));
                this.setLastName(r.getString("LAST_NAME"));
                this.setBirthDate((java.util.Date)r.getDate("BIRTH_DATE"));
                this.setGender(r.getString("GENDER"));
                this.setMaritalStatus(r.getString("MARITAL_STATUS"));
                this.setSsn(r.getString("SOCIAL_SECURITY_NUMBER"));
                this.setReferredBy(r.getString("REFERRED_BY"));
                this.setStudent(r.getString("STUDENT"));
                this.setEmailAddress(r.getString("EMAIL_ADDRESS"));
                this.setOccupation(r.getString("OCCUPATION"));
                this.setEmployer(r.getString("EMPLOYER"));
                this.setHeadOfHousehold(r.getString("HEAD_OF_HOUSEHOLD"));
                this.setRelation(r.getString("RELATION"));
                this.setProvider(r.getString("PROVIDER"));
                this.setProviderPlan(r.getString("PROVIDER_PLAN"));
                this.setMobileNumber(r.getString("MOBILE_NUMBER"));
                this.setHomePhoneNumber(r.getString("HOME_PHONE_NUMBER"));
                this.setOfficePhoneNumber(r.getString("OFFICE_PHONE_NUMBER"));
                this.setHomeAddress1(r.getString("HOME_ADDRESS1"));
                this.setHomeAddress2(r.getString("HOME_ADDRESS2"));
                this.setHomeCity(r.getString("HOME_CITY"));
                this.setHomeState(r.getString("HOME_STATE"));
                this.setHomeZip(r.getString("HOME_ZIP"));
                this.setOfficeAddress1(r.getString("OFFICE_ADDRESS1"));
                this.setOfficeAddress2(r.getString("OFFICE_ADDRESS2"));
                this.setOfficeCity(r.getString("OFFICE_CITY"));
                this.setOfficeState(r.getString("OFFICE_STATE"));
                this.setOfficeZip(r.getString("OFFICE_ZIP"));
                this.setAccountId(r.getString("ACCOUNT_ID"));                
                retval= true;
            }
            return retval;
        } catch (Exception e) {
            return false;
        }            
    }
    
    public boolean add() {
        WebController ctr=new WebController();
        this.setPartyId("");
        this.setFirstName("");
        this.setMiddleName("");
        this.setLastName("");
        this.setBirthDate(ctr.BLANKDATE());
        this.setGender("M");
        this.setMaritalStatus("S");
        this.setReferredBy("");
        this.setStudent("");
        this.setEmailAddress("");
        this.setMobileNumber("");
        this.setHomePhoneNumber("");
        this.setOfficePhoneNumber("");
        this.setHomeAddress1("");
        this.setHomeAddress2("");
        this.setHomeCity("");
        this.setHomeState("");
        this.setHomeZip("");
        this.setOccupation("");
        this.setSsn("");
        this.setEmployer("");
        this.setOfficeAddress1("");
        this.setOfficeAddress2("");
        this.setOfficeCity("");
        this.setOfficeState("");
        this.setOfficeZip("");
        this.setHeadOfHousehold("");
        this.setRelation("S");
        this.setProvider("");
        this.setProviderPlan("");
        this.setAccountId("");
        return true;
    }
    
    public boolean delete() {
        return false;
    }
    
    public boolean save() {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();

            SQLHelper h=new SQLHelper();
            String sql;
            Statement s;
            ResultSet r;
            boolean ok;
            if (this.getPartyId().equals("")) {
                sql="SELECT * FROM patient";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                r.moveToInsertRow();
                ok=true;
            } else {
                sql="SELECT * FROM patient WHERE PARTY_ID=\""+this.getPartyId()+"\"";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                ok=r.next();
            }
            if (ok) {
                r.updateString("FIRST_NAME", this.getFirstName());
                r.updateString("MIDDLE_NAME", this.getMiddleName());
                r.updateString("LAST_NAME", this.getLastName());
                r.updateDate("BIRTH_DATE",(this.getBirthDate().equals(ctr.BLANKDATE()))?null:new java.sql.Date(this.getBirthDate().getTime()));
                r.updateString("GENDER", this.getGender());
                r.updateString("MARITAL_STATUS", this.getMaritalStatus());
                r.updateString("SOCIAL_SECURITY_NUMBER",this.getSsn());
                r.updateString("REFERRED_BY", this.getReferredBy());
                r.updateString("STUDENT", this.getStudent());
                r.updateString("EMAIL_ADDRESS", this.getEmailAddress());
                r.updateString("OCCUPATION", this.getOccupation());
                r.updateString("EMPLOYER", this.getEmployer());
                r.updateString("HEAD_OF_HOUSEHOLD", this.getHeadOfHousehold());
                r.updateString("RELATION", this.getRelation());
                r.updateString("PROVIDER", this.getProvider());
                r.updateString("PROVIDER_PLAN", this.getProviderPlan());
                r.updateString("MOBILE_NUMBER", this.getMobileNumber());
                r.updateString("HOME_PHONE_NUMBER", this.getHomePhoneNumber());
                r.updateString("OFFICE_PHONE_NUMBER", this.getOfficePhoneNumber());
                r.updateString("HOME_ADDRESS1", this.getHomeAddress1());
                r.updateString("HOME_ADDRESS2", this.getHomeAddress2());
                r.updateString("HOME_CITY", this.getHomeCity());
                r.updateString("HOME_STATE", this.getHomeState());
                r.updateString("HOME_ZIP", this.getHomeZip());
                r.updateString("OFFICE_ADDRESS1", this.getOfficeAddress1());
                r.updateString("OFFICE_ADDRESS2", this.getOfficeAddress2());
                r.updateString("OFFICE_CITY", this.getOfficeCity());
                r.updateString("OFFICE_STATE", this.getOfficeState());
                r.updateString("OFFICE_ZIP", this.getOfficeZip());
                r.updateString("ACCOUNT_ID", this.getAccountId());
                if (this.getPartyId().equals("")) {
                    Timestamp x=new Timestamp(System.currentTimeMillis());
                    r.updateTimestamp("CREATED_STAMP", x);
                    r.updateTimestamp("LAST_UPDATED_STAMP", x);                       
                    h.insertAutoKey("patient", "PARTY_ID", r, c);
                } else {
                    Timestamp x=new Timestamp(System.currentTimeMillis());
                    r.updateTimestamp("LAST_UPDATED_STAMP", x);   
                    r.updateRow();
                }
                return true;
            } else {
                return false; //not ok
            }
            
        } catch (Exception e) {
            return false;
        }
    }    
}
