/*
 * Exam.java
 * 
 * Created on Sep 7, 2007, 2:08:08 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;

/**
 *
 * @author nsdan2k
 */
public class Exam {

    public Exam() {
        this.setErrMessage("");
    }

    private int id;
    private String dentalUnit;
    private String doctorId;
    private String doctor;
    private String patientId;
    private String patient;
    private String accountId;
    private String treatmentId;
    private String errMessage;
    private Timestamp createdStamp;

    public Timestamp getCreatedStamp() {
        return createdStamp;
    }

    public void setCreatedStamp(Timestamp createdStamp) {
        this.createdStamp = createdStamp;
    }

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getDentalUnit() {
        return dentalUnit;
    }

    public void setDentalUnit(String dentalUnit) {
        this.dentalUnit = dentalUnit;
    }

    public String getDoctor() {
        return doctor;
    }

    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public String getPatient() {
        return patient;
    }

    public void setPatient(String patient) {
        this.patient = patient;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getTreatmentId() {
        return treatmentId;
    }

    public void setTreatmentId(String treatmentId) {
        this.treatmentId = treatmentId;
    }
    
    public int checkin() {
        model.Treatment treatment=new model.Treatment();
        treatment.setAccountId(this.getAccountId());
        treatment.setDentalUnit(this.getDentalUnit());
        treatment.setDoctorId(this.getDoctorId());
        treatment.setDoctor(this.getDoctor());
        treatment.setPatientId(this.getPatientId());  
        int Tid=treatment.create();
        if (Tid!=0) { 
            WebController ctr=new WebController();
            DBConnectionManager db=new DBConnectionManager();
            try {
                Connection c=db.getConnection();
                this.setErrMessage("");
                SQLHelper h=new SQLHelper();
                String sql;
                Statement s;
                ResultSet r;
                int retval=0;
                String t=ctr.convertTimeStampToString(ctr.TIMESTAMP());
                sql="SELECT * FROM exam";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                r.moveToInsertRow();
                r.updateInt("TREATMENT_ID", Tid);
                r.updateString("ACCOUNT_ID",this.getAccountId());
                Timestamp x=new Timestamp(System.currentTimeMillis());
                r.updateTimestamp("CREATED_STAMP", x);
                r.updateTimestamp("LAST_UPDATED_STAMP", x);            
                r.insertRow();
                return Tid;
  
        } catch (Exception e) {
                this.setErrMessage(e.getMessage());
                return 0;
            }      
        } else {
            this.setErrMessage(treatment.getErrMessage());
            return 0;
        }
    }
    public boolean checkout(String id, String account) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            
            String sql2="SELECT * FROM exam WHERE ID = "+id;
            Statement s2=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r2=s2.executeQuery(sql2);
            if (r2.next()) {
                int tId=r2.getInt("TREATMENT_ID");
                String sql3="SELECT * FROM treatment WHERE TREATMENT_ID = "+tId;
                Statement s3=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                ResultSet r3=s3.executeQuery(sql3);
                if (r3.next()) {
                    r3.updateTimestamp("TIME_TO", ctr.TIMESTAMP());
                    r3.updateRow();
                }
            }

            String sql="DELETE FROM exam WHERE ID = "+id;
            Statement s=c.createStatement();
            int count=s.executeUpdate(sql);

            return (count>0);
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }      
    }
    
    public boolean fetch(String id, String account) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();

            String sql="SELECT * FROM exam WHERE ID=\""+id+"\" AND ACCOUNT_ID=\""+account+"\"";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            while (r.next()) {
                this.setId(r.getInt("ID"));
                this.setAccountId(r.getString("ACCOUNT_ID"));
                this.setCreatedStamp(r.getTimestamp("CREATED_STAMP"));
                model.Treatment treatment=new model.Treatment();
                if (treatment.fetch(r.getString("TREATMENT_ID"), account)) {
                    this.setDentalUnit(treatment.getDentalUnit());
                    this.setDoctorId(treatment.getDoctorId());
                    this.setDoctor(treatment.getDoctor());
                    this.setPatientId(treatment.getPatientId());
                    this.setPatient(treatment.getPatient());
                    this.setTreatmentId(treatment.getTreatmentId());
                    retval=true;
                } else {
                    retval=false;
                }
            }
            return retval;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }            
    }
}
