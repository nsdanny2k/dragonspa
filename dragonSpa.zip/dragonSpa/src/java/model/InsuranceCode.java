/*
 * InsuranceCode.java
 * 
 * Created on Sep 9, 2007, 3:14:44 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author nsdan2k
 */
public class InsuranceCode {

    public InsuranceCode() {
        this.setErrMessage("");
    }
    
    private int id;
    private String code;
    private String description;
    private String phoneNumber;
    private String faxNumber;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String zip;
    private String accountId;
    private String errMessage;

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFaxNumber() {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }
    
    
    public boolean fetch(int id, String account) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();

            String sql="SELECT * FROM insurancecode WHERE ID="+id+" AND ACCOUNT_ID=\""+account+"\"";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            while (r.next()) {
                this.setId(id);
                this.setCode(r.getString("CODE"));
                this.setDescription(r.getString("DESCRIPTION"));
                this.setFaxNumber(r.getString("FAX_NUMBER"));
                this.setPhoneNumber(r.getString("PHONE_NUMBER"));
                this.setAddress1(r.getString("ADDRESS1"));
                this.setAddress2(r.getString("ADDRESS2"));
                this.setCity(r.getString("CITY"));
                this.setState(r.getString("STATE"));
                this.setZip(r.getString("ZIP"));
                this.setAccountId(r.getString("ACCOUNT_ID"));                
                retval= true;
            }
            return retval;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }            
    }
    
    public boolean add() {
        this.setErrMessage("");
        WebController ctr=new WebController();
        this.setId(0);
        this.setCode("");
        this.setDescription("");
        this.setFaxNumber("");
        this.setPhoneNumber("");
        this.setAddress1("");
        this.setAddress2("");
        this.setCity("");
        this.setState("");
        this.setZip("");
        this.setAccountId(""); 
        return true;
    }
    
    public boolean delete() {
        this.setErrMessage("");
        return false;
    }
    
    public boolean save() {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql;
            Statement s;
            ResultSet r;
            boolean ok;
            if (this.getId()==0) {
                sql="SELECT * FROM insurancecode";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                r.moveToInsertRow();
                ok=true;
            } else {
                sql="SELECT * FROM insurancecode WHERE ID="+this.getId()+"";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                ok=r.next();
            }
            if (ok) {
                r.updateString("CODE", this.getCode());
                r.updateString("DESCRIPTION",this.getDescription());
                r.updateString("FAX_NUMBER",this.getFaxNumber());
                r.updateString("PHONE_NUMBER",this.getPhoneNumber());
                r.updateString("ADDRESS1",this.getAddress1());
                r.updateString("ADDRESS2",this.getAddress2());
                r.updateString("CITY",this.getCity());
                r.updateString("STATE",this.getState());
                r.updateString("ZIP",this.getZip());
                r.updateString("ACCOUNT_ID", this.getAccountId());
                if (this.getId()==0) {
                    r.insertRow();
                } else {
                    r.updateRow();
                }
                return true;
            } else {
                return false; //not ok
            }
            
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }
    }     
}
