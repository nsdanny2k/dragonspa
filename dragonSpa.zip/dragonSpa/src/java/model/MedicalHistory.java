/*
 * MedicalHistory.java
 * 
 * Created on Sep 13, 2007, 4:48:02 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author nsdan2k
 */
public class MedicalHistory extends Vector {

    public MedicalHistory() {
        this.setErrMessage("");
    }
    
    private String errMessage;

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    public boolean reset(String partyId, String account) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql="DELETE FROM medicalhistory WHERE PARTY_ID=\'"+partyId+"\' AND ACCOUNT_ID=\""+account+"\"";
            Statement s=c.createStatement();
            int count=s.executeUpdate(sql);
            return true;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }   
    }
    
    public boolean create(int alertId, String partyId, String account) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql="SELECT * FROM medicalhistory";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            r.moveToInsertRow();    
            r.updateInt("ALERT_ID",alertId);
            r.updateString("PARTY_ID", partyId);
            r.updateString("ACCOUNT_ID", account);
            r.insertRow();
            return true;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }            
    }
    
    public boolean lookup(int alertId, String partyId, String account) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql="SELECT * FROM medicalhistory WHERE ALERT_ID="+alertId+" AND PARTY_ID=\'"+partyId+"\' AND ACCOUNT_ID=\""+account+"\"";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            while (r.next()) {
                retval=true;
            }
            return retval;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }            
    } 
    
    public int fetch(String partyId, String account) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.MedicalAlert alert;
        try {
            int i=0;
            Connection c=db.getConnection();
            String sql="SELECT * FROM medicalhistory WHERE PARTY_ID=\'"+partyId+"\' AND ACCOUNT_ID=\""+account+"\"";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {

                i=i+1;
                alert=new model.MedicalAlert();
                if (alert.fetch(r.getInt("ALERT_ID"), "system")) {
                    this.add(alert);
                }
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }
    
}
