/*
 * Attribute.java
 * 
 * Created on Sep 3, 2007, 8:32:36 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;

/**
 *
 * @author nsdan2k
 */
public class Attribute {

    public Attribute() {
    }

    public Attribute(String table, String pkid) {
        this.table=table;
        this.pkid=pkid;
    }
    
    private String table;
    private String pkid;

    public String getPkid() {
        return pkid;
    }

    public void setPkid(String pkid) {
        this.pkid = pkid;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }
    
    public boolean updateAttribute(String id, String attrName, String attrValue, Connection c) {
        int count2=0;
        try {
            String sql2="SELECT * FROM "+table+" WHERE "+pkid+"="+id+" AND ATTR_NAME=\""+attrName+"\"";
            Statement s2=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r2=s2.executeQuery(sql2);
            Timestamp x2=new Timestamp(System.currentTimeMillis());
            while (r2.next()) {
                if (attrValue.equals("")) {
                    r2.deleteRow();
                } else {
                    r2.updateString("ATTR_VALUE", attrValue);
                    r2.updateTimestamp("LAST_UPDATED_STAMP", x2);
                    r2.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                    r2.updateRow();
                }
                count2 = count2 + 1;
            }
            if (count2 < 1) {
                if (!attrValue.equals("")) {
                    r2.moveToInsertRow();
                    r2.updateString("PARTY_ID",id);
                    r2.updateString("ATTR_NAME", attrName);
                    r2.updateString("ATTR_VALUE", attrValue);
                    r2.updateTimestamp("CREATED_STAMP", x2);
                    r2.updateTimestamp("CREATED_TX_STAMP", x2);
                    r2.updateTimestamp("LAST_UPDATED_STAMP", x2);
                    r2.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                    r2.insertRow();
                }
            }        
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
}
