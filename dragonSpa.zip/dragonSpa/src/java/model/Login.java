/*
 * Login.java
 * 
 * Created on Aug 30, 2007, 4:56:55 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author nsdan2k
 */
public class Login {

    public Login() {
        user="";
        password="";
        authorized=false;
        accountId="";
    }
    
    private String user;
    private String password;
    private String displayName;
    private String lastForm;
    private String accountId;
    private boolean authorized;
    private String country;
    private int accountNumber;
    private String notation;
    private int extended;
    private String commission;

    public int getExtended() {
        return extended;
    }

    public void setExtended(int extended) {
        this.extended = extended;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public boolean isAuthorized() {
        return authorized;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getLastForm() {
        return lastForm;
    }

    public void setLastForm(String lastForm) {
        this.lastForm = lastForm;
    }

    public String getPassword() {
        return password;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getUser() {
        return user;
    }

    public String getNotation() {
        return notation;
    }

    public void setNotation(String notation) {
        this.notation = notation;
    }
 
   public String getCommission() {
        return commission;
    }

    public void setCommission(String commission) {
        this.commission = commission;
    }
    
    public boolean signIn(String usr, String pwd) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            int i=0;
            Connection c=db.getConnection();
            String sql="SELECT * FROM account WHERE PARTY_ID = \'"+usr+"\' AND PASSWORD = \'"+pwd+"\'";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                this.setUser(usr);
                this.setPassword(pwd);   
                this.setDisplayName(usr);
                this.authorized=true;
                this.setAccountNumber(r.getInt("ACCOUNT_NUMBER"));
                this.setAccountId(r.getString("ACCOUNT_ID"));
                model.Account account=new model.Account();
                account.fetchMain(r.getString("ACCOUNT_ID"));
                this.setNotation(account.getNotation());
                this.setCountry(account.getCountry());
                this.setExtended(account.getExtended());
                this.setCommission(account.getZip());
                retval=true;
            }
            return retval;
        } catch (Exception e) {
            return false;        
        }
    }
    
    public void refresh() {
        model.Account account=new model.Account();
        account.fetchMain(this.getAccountId());
        this.setNotation(account.getNotation());
        this.setCountry(account.getCountry());
        this.setExtended(account.getExtended());
        this.setCommission(account.getZip());
    }
        
    public boolean signOut() {
            this.setUser("");
            this.setPassword("");   
            this.setDisplayName("");
            this.authorized=false;
            this.setAccountId("");
            this.setAccountNumber(0);
            this.setNotation("");
            this.setExtended(0);
            this.setCommission("");
            return true;
    }

}
