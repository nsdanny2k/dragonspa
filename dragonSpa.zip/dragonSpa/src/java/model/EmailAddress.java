/*
 * EmailAddress.java
 * 
 * Created on Sep 3, 2007, 9:53:25 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

/**
 *
 * @author nsdan2k
 */
public class EmailAddress {

    public EmailAddress() {
    }

}
