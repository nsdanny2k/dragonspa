/*
 * TreatmentDetails.java
 * 
 * Created on Sep 10, 2007, 2:17:33 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author nsdan2k
 */
public class TreatmentDetails extends Vector {

    public TreatmentDetails() {
    }

    private int sets;

    public int getSets() {
        return sets;
    }
    
    public int fetch(int id) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.TreatmentDetail code;
        try {
            int i=0;
            Connection c=db.getConnection();
            String sql="SELECT * FROM treatment_entry WHERE TREATMENT_ID="+id+" ORDER BY ID";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                i=i+1;
                code=new model.TreatmentDetail();
                code.fetch(r.getInt("ID"));
                this.add(code);
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }

    public int fetchHistory(String partyId, int from, int count) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.TreatmentDetail detail;
        try {
            int i=0;
            int j=0;
            Connection c=db.getConnection();
            String sql="SELECT treatment.DATE_VISIT, treatment_entry.* FROM treatment_entry, treatment WHERE treatment.TREATMENT_ID=treatment_entry.TREATMENT_ID AND treatment.PATIENT_ID = \'"+partyId+"\' ORDER BY treatment_entry.ID desc";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {

                i=i+1;
                if ((i<(from-1)*(count)+1))  {
                    //skip
                } else {
                    j=j+1;
                    if (j<=count) {                
                        detail=new model.TreatmentDetail();
                        if (detail.fetch(r.getInt("ID"))) {
                            detail.setDateVisit((java.util.Date)r.getDate("DATE_VISIT"));
                            this.add(detail);
                        }
                    }
                }
            }
            this.sets=i/count;
            if((i % count)>0) {
                this.sets=this.sets+1;
            }    
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }
    
    public String lookupControlNumber(int id) {
        String retval="";
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.ProcedureCode code;
        try {
            Connection c=db.getConnection();
            String sql="SELECT * FROM treatment WHERE TREATMENT_ID="+id;
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                retval=r.getString("CONTROL_NUMBER");
            }
            return retval;
        } catch (Exception e) {
            return "";        
        }      
    }   
    
    public int getLastTransaction(int partyId) {
        int retval=0;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.ProcedureCode code;
        try {
            Connection c=db.getConnection();
            String sql="SELECT * FROM treatment WHERE PATIENT_ID = \'"+partyId+"\' ORDER BY TREATMENT_ID DESC";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            if (r.next()) {
                retval=r.getInt("TREATMENT_ID");
            }
            return retval;
        } catch (Exception e) {
            return -1;        
        }      
    }     
}
