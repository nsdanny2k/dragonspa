/*
 * TelecomNumber.java
 * 
 * Created on Sep 3, 2007, 12:49:47 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.GregorianCalendar;

/**
 *
 * @author nsdan2k
 */
public class TelecomNumber {

    public TelecomNumber() {
    }

    private String id;
    private String countryCode;
    private String areaCode;
    private String contactNumber;
    private String partyId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
    
    public boolean updateNumber(String purpose, String partyId, String countryCode, String areaCode, String contactNumber, Connection c) {
        int count2=0;
        String id2="";
        String sql="";
        Statement s;
        ResultSet r;
        SQLHelper h=new SQLHelper();

        int count;
        try {
            
            
            String sql2="SELECT * FROM party_contact_mech_purpose WHERE PARTY_ID=\""+partyId+"\" AND CONTACT_MECH_PURPOSE_TYPE_ID=\""+purpose+"\"";
            Statement s2=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r2=s2.executeQuery(sql2);

            Timestamp x2=new Timestamp(System.currentTimeMillis());
            Date x1=new java.sql.Date((new GregorianCalendar(2001, 0, 1)).getTime().getTime());
            while (r2.next()) {
                id2=r2.getString("CONTACT_MECH_ID");
                
                if (contactNumber.equals("")) {
                    
                    sql="DELETE FROM telecom_number WHERE CONTACT_MECH_ID="+id2;
                    s=c.createStatement();
                    count=s.executeUpdate(sql);   
                    
                    sql="DELETE FROM party_contact_mech WHERE CONTACT_MECH_ID="+id2;
                    s=c.createStatement();
                    count=s.executeUpdate(sql);   

                    r2.deleteRow();

                    sql="DELETE FROM contact_mech WHERE CONTACT_MECH_ID="+id2;
                    s=c.createStatement();
                    count=s.executeUpdate(sql);   
                
                } else {
                    
                    String sql3="SELECT * FROM telecom_number WHERE CONTACT_MECH_ID="+id2;
                    Statement s3=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                    ResultSet r3=s3.executeQuery(sql3);
                    while (r3.next()) {
                        r3.updateString("COUNTRY_CODE", countryCode );
                        r3.updateString("AREA_CODE", areaCode );
                        r3.updateString("CONTACT_NUMBER", contactNumber );
                        r3.updateTimestamp("LAST_UPDATED_STAMP", x2);
                        r3.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                        r3.updateRow();
                        break;
                    }
                }
                count2 = count2 + 1;
            }
            
            if (count2 < 1) {
                if (!contactNumber.equals("")) {

                    sql="SELECT * FROM contact_mech";
                    s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                    r=s.executeQuery(sql);
                    r.moveToInsertRow();
                    String desc=countryCode+" "+areaCode+" "+contactNumber;
                    r.updateString("CONTACT_MECH_TYPE_ID","TELECOM_NUMBER");
                    r.updateString("INFO_STRING", desc);
                    r.updateTimestamp("CREATED_STAMP", x2);
                    r.updateTimestamp("CREATED_TX_STAMP", x2);
                    r.updateTimestamp("LAST_UPDATED_STAMP", x2);
                    r.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                    h.insertAutoKey("contact_mech", "CONTACT_MECH_ID", r, c);

                    sql="SELECT * FROM contact_mech WHERE INFO_STRING = \""+desc+"\"";
                    s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                    r=s.executeQuery(sql);
                    while (r.next()) {
                        id2=r.getString("CONTACT_MECH_ID");

                        sql="UPDATE contact_mech SET INFO_STRING=null WHERE CONTACT_MECH_ID="+id2;
                        s=c.createStatement();
                        count=s.executeUpdate(sql);     
                        
                        String sql4="SELECT * FROM telecom_number";
                        Statement s4=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                        ResultSet r4=s4.executeQuery(sql4);  
                        r4.moveToInsertRow();
                        r4.updateString("CONTACT_MECH_ID", id2);
                        r4.updateString("COUNTRY_CODE",countryCode);
                        r4.updateString("AREA_CODE",areaCode);
                        r4.updateString("CONTACT_NUMBER",contactNumber);
                        r4.updateTimestamp("CREATED_STAMP", x2);
                        r4.updateTimestamp("CREATED_TX_STAMP", x2);
                        r4.updateTimestamp("LAST_UPDATED_STAMP", x2);
                        r4.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                        r4.insertRow();
                        
                        sql4="SELECT * FROM party_contact_mech";
                        s4=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                        r4=s4.executeQuery(sql4);  
                        r4.moveToInsertRow();
                        r4.updateString("PARTY_ID", partyId);
                        r4.updateString("CONTACT_MECH_ID", id2);
                        r4.updateDate("FROM_DATE", x1);
                        r4.updateTimestamp("CREATED_STAMP", x2);
                        r4.updateTimestamp("CREATED_TX_STAMP", x2);
                        r4.updateTimestamp("LAST_UPDATED_STAMP", x2);
                        r4.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                        r4.insertRow();
                        
                        r2.moveToInsertRow();
                        r2.updateString("PARTY_ID", partyId);
                        r2.updateString("CONTACT_MECH_ID", id2);
                        r2.updateString("CONTACT_MECH_PURPOSE_TYPE_ID",purpose);
                        r2.updateDate("FROM_DATE", x1);
                        r2.updateTimestamp("CREATED_STAMP", x2);
                        r2.updateTimestamp("CREATED_TX_STAMP", x2);
                        r2.updateTimestamp("LAST_UPDATED_STAMP", x2);
                        r2.updateTimestamp("LAST_UPDATED_TX_STAMP", x2);
                        r2.insertRow();
                    
                        break;
                    }
                }
            }        
            return true;
             
            
        } catch (Exception e) {
            return false;
        } 
        
    }
    
}
