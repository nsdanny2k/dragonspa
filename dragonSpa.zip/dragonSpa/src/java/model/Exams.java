/*
 * Exams.java
 * 
 * Created on Sep 7, 2007, 1:45:03 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author nsdan2k
 */
public class Exams extends Vector {

    public Exams() {
    }
    
    public int fetch(String account) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.Exam exam;
        model.Treatment treatment;
        try {
            int i=0;
            Connection c=db.getConnection();
            String sql="SELECT * FROM exam WHERE ACCOUNT_ID=\'"+account+"\' ORDER BY ID";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                i=i+1;
                exam=new model.Exam();
                exam.fetch(r.getString("ID"), account);
                this.add(exam);
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }    

    
}
