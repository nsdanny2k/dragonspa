/*
 * Countries.java
 * 
 * Created on Sep 9, 2007, 12:58:12 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author nsdan2k
 */
public class Countries extends Vector {

    public Countries() {
    }
    public int fetch() {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.Country country;
        try {
            int i=0;
            Connection c=db.getConnection();
            String sql="SELECT * FROM country_code ORDER BY COUNTRY_NAME";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                i=i+1;
                country=new model.Country();
                country.setCode(r.getString("COUNTRY_CODE"));
                country.setDescription(r.getString("COUNTRY_NAME"));
                this.add(country);
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }
    
}
