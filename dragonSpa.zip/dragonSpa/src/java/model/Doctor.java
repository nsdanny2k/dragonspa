/*
 * Patient.java
 * 
 * Created on Sep 5, 2007, 9:49:24 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author nsdan2k
 */
public class Doctor {

    public Doctor() {
        this.setErrMessage("");
    }
    private String partyId;
    private String accountId;
    private String firstName;
    private String middleName;
    private String lastName;
    private String credentials;
    private String ssn;
    private String licenseNumber;
    private String phoneNumber;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String zip;
    private double dailyRate;
    private String errMessage;

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    public double getDailyRate() {
        return dailyRate;
    }

    public void setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCredentials() {
        return credentials;
    }

    public void setCredentials(String credentials) {
        this.credentials = credentials;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    
    public boolean search(String name) {
        return false;
    }
    
    public boolean fetch(String id, String account) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();

            String sql="SELECT * FROM doctor WHERE PARTY_ID=\""+id+"\" AND ACCOUNT_ID=\""+account+"\"";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            while (r.next()) {
                this.setPartyId(r.getString("PARTY_ID"));
                this.setFirstName(r.getString("FIRST_NAME"));
                this.setMiddleName(r.getString("MIDDLE_NAME"));
                this.setLastName(r.getString("LAST_NAME"));
                this.setCredentials(r.getString("CREDENTIALS"));
                this.setLicenseNumber(r.getString("LICENSE_NUMBER"));
                this.setSsn(r.getString("SOCIAL_SECURITY_NUMBER"));
                this.setPhoneNumber(r.getString("PHONE_NUMBER"));
                this.setAddress1(r.getString("ADDRESS1"));
                this.setAddress2(r.getString("ADDRESS2"));
                this.setCity(r.getString("CITY"));
                this.setState(r.getString("STATE"));
                this.setZip(r.getString("ZIP"));
                this.setAccountId(r.getString("ACCOUNT_ID"));   
                this.setDailyRate(r.getDouble("DAILY_RATE"));
                retval= true;
            }
            return retval;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }            
    }
    
    public boolean add() {
        this.setErrMessage("");
        WebController ctr=new WebController();
        this.setPartyId("");
        this.setFirstName("");
        this.setMiddleName("");
        this.setLastName("");
        this.setCredentials("");
        this.setLicenseNumber("");
        this.setSsn("");
        this.setPhoneNumber("");
        this.setAddress1("");
        this.setAddress2("");
        this.setCity("");
        this.setState("");
        this.setZip("");
        this.setAccountId(""); 
        this.setDailyRate(0);
        return true;
    }
    
    public boolean delete() {
        this.setErrMessage("");
        return false;
    }
    
    public boolean save() {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql;
            Statement s;
            ResultSet r;
            boolean ok;
            if (this.getPartyId().equals("")) {
                sql="SELECT * FROM doctor";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                r.moveToInsertRow();
                ok=true;
            } else {
                sql="SELECT * FROM doctor WHERE PARTY_ID=\""+this.getPartyId()+"\"";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                ok=r.next();
            }
            if (ok) {
                r.updateString("FIRST_NAME", this.getFirstName());
                r.updateString("MIDDLE_NAME", this.getMiddleName());
                r.updateString("LAST_NAME", this.getLastName());
                r.updateString("CREDENTIALS", this.getCredentials());
                r.updateString("LICENSE_NUMBER", this.getLicenseNumber());
                r.updateString("SOCIAL_SECURITY_NUMBER", this.getSsn());
                r.updateString("PHONE_NUMBER",this.getPhoneNumber());
                r.updateString("ADDRESS1",this.getAddress1());
                r.updateString("ADDRESS2",this.getAddress2());
                r.updateString("CITY",this.getCity());
                r.updateString("STATE",this.getState());
                r.updateString("ZIP",this.getZip());
                r.updateString("ACCOUNT_ID", this.getAccountId());
                r.updateDouble("DAILY_RATE", this.getDailyRate());
                if (this.getPartyId().equals("")) {
                    h.insertAutoKey("doctor", "PARTY_ID", r, c);
                } else {
                    r.updateRow();
                }
                return true;
            } else {
                return false; //not ok
            }
            
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }
    }    
}
