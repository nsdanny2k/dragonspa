/*
 * Patients.java
 * 
 * Created on Sep 4, 2007, 2:18:09 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author nsdan2k
 */
public class Patients extends Vector {

    public Patients() {
    }
    
    private int sets;

    public int getSets() {
        return sets;
    }

    public int search( String name, String account) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        int i=0;
        int j=0;
        model.Patient patient;
        try {
            Connection c=db.getConnection();
            String sql="SELECT * FROM patient WHERE CONCAT(LOWER(FIRST_NAME),\' \',LOWER(LAST_NAME)) = \'"+name.toLowerCase()+"\' AND ACCOUNT_ID=\'"+account+"\' ORDER BY LAST_NAME, FIRST_NAME" ;
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                i=i+1;
                patient=new Patient();
                patient.setPartyId(r.getString("PARTY_ID"));
                patient.setFirstName(r.getString("FIRST_NAME"));
                patient.setMiddleName(r.getString("MIDDLE_NAME"));
                patient.setLastName(r.getString("LAST_NAME"));
                patient.setGender(r.getString("GENDER"));
                patient.setMaritalStatus(r.getString("MARITAL_STATUS"));
                patient.setBirthDate((java.util.Date)r.getDate("BIRTH_DATE"));
                this.add(patient);
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }
    
    public int search2( String name, String account) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        int i=0;
        int j=0;
        model.Patient patient;
        try {
            Connection c=db.getConnection();
            String[] pattern=name.split(" ");
            if (pattern.length==2) {
                String firstname=pattern[0];
                String lastname=pattern[1];
                String sql="SELECT * FROM patient WHERE LOWER(FIRST_NAME) = \'"+firstname.toLowerCase()+"\' AND LOWER(LAST_NAME) = \'"+lastname.toLowerCase()+"\' AND ACCOUNT_ID=\'"+account+"\' ORDER BY LAST_NAME, FIRST_NAME" ;
                Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                ResultSet r=s.executeQuery(sql);
                SQLHelper h=new SQLHelper();        
                while (r.next()) {
                    i=i+1;
                    patient=new Patient();
                    patient.setPartyId(r.getString("PARTY_ID"));
                    patient.setFirstName(r.getString("FIRST_NAME"));
                    patient.setMiddleName(r.getString("MIDDLE_NAME"));
                    patient.setLastName(r.getString("LAST_NAME"));
                    patient.setGender(r.getString("GENDER"));
                    patient.setMaritalStatus(r.getString("MARITAL_STATUS"));
                    patient.setBirthDate((java.util.Date)r.getDate("BIRTH_DATE"));
                    this.add(patient);
                }
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }
    
    public int fetchAlphabetical(String account, String pattern, int from, int count) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        int i=0;
        int j=0;
        model.Patient patient;
        try {
            Connection c=db.getConnection();
            String sql="SELECT * FROM patient WHERE LAST_NAME LIKE \'"+pattern+"%\' AND ACCOUNT_ID=\'"+account+"\' ORDER BY LAST_NAME, FIRST_NAME" ;
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                
                i=i+1;
                if ((i<(from-1)*(count)+1))  {
                    //skip
                } else {
                    j=j+1;
                    if (j<=count) {        
                        patient=new model.Patient();
                        patient.setPartyId(r.getString("PARTY_ID"));
                        patient.setFirstName(r.getString("FIRST_NAME"));
                        patient.setMiddleName(r.getString("MIDDLE_NAME"));
                        patient.setLastName(r.getString("LAST_NAME"));
                        patient.setGender(r.getString("GENDER"));
                        patient.setMaritalStatus(r.getString("MARITAL_STATUS"));
                        patient.setBirthDate((java.util.Date)r.getDate("BIRTH_DATE"));
                        this.add(patient);
                    }
                }
                
            }
            this.sets=i/count;
            if((i % count)>0) {
                this.sets=this.sets+1;
            }    
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }
    
    public int fetch(String account) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        int i=0;
        model.Patient patient;
        try {
            Connection c=db.getConnection();
            String sql="SELECT * FROM patient WHERE ACCOUNT_ID=\'"+account+"\' ORDER BY  FIRST_NAME, LAST_NAME, MIDDLE_NAME" ;
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                i=i+1;
                patient=new model.Patient();
                patient.setPartyId(r.getString("PARTY_ID"));
                patient.setFirstName(r.getString("FIRST_NAME"));
                patient.setMiddleName(r.getString("MIDDLE_NAME"));
                patient.setLastName(r.getString("LAST_NAME"));
                patient.setGender(r.getString("GENDER"));
                patient.setMaritalStatus(r.getString("MARITAL_STATUS"));
                patient.setBirthDate((java.util.Date)r.getDate("BIRTH_DATE"));
                this.add(patient);
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }    
}
