/*
 * TreatmentDetails.java
 * 
 * Created on Sep 26, 2007, 2:17:33 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author nsdan2k
 */
public class TreatmentCommissions extends Vector {

    public TreatmentCommissions() {
    }

  
    public int fetch(int id) {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        model.TreatmentCommission code;
        try {
            int i=0;
            Connection c=db.getConnection();
            String sql="SELECT * FROM treatmentcommissions WHERE TREATMENT_ID="+id+" ORDER BY ID";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            SQLHelper h=new SQLHelper();        
            while (r.next()) {
                i=i+1;
                code=new model.TreatmentCommission();
                code.fetch(r.getInt("ID"));
                this.add(code);
            }
            return i;
        } catch (Exception e) {
            return 0;        
        }
    }

    
   
}