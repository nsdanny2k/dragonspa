/*
 * ProcedureCode.java
 * 
 * Created on Sep 9, 2007, 3:05:52 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import com.ownx.db.SQLHelper;
import com.ownx.util.WebController;
import general.DBConnectionManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author nsdan2k
 */
public class ProcedureCode {

    public ProcedureCode() {
        this.setErrMessage("");
    }

    private int id;
    private String code;
    private String description;
    private double rate;
    private String accountId;
    private String errMessage;

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public boolean fetch(int id, String account) {
        boolean retval=false;
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();

            String sql="SELECT * FROM procedurecode WHERE ID="+id+" AND ACCOUNT_ID=\""+account+"\"";
            Statement s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
            ResultSet r=s.executeQuery(sql);
            while (r.next()) {
                this.setId(id);
                this.setCode(r.getString("CODE"));
                this.setDescription(r.getString("DESCRIPTION"));
                this.setAccountId(r.getString("ACCOUNT_ID"));                
                this.setRate(r.getDouble("RATE"));
                retval= true;
            }
            return retval;
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }            
    }
    
    public boolean add() {
        this.setErrMessage("");
        WebController ctr=new WebController();
        this.setId(0);
        this.setCode("");
        this.setDescription("");
        this.setAccountId(""); 
        this.setRate(0);
        return true;
    }
    
    public boolean delete() {
        this.setErrMessage("");
        return false;
    }
    
    public boolean save() {
        WebController ctr=new WebController();
        DBConnectionManager db=new DBConnectionManager();
        try {
            Connection c=db.getConnection();
            this.setErrMessage("");
            SQLHelper h=new SQLHelper();
            String sql;
            Statement s;
            ResultSet r;
            boolean ok;
            if (this.getId()==0) {
                sql="SELECT * FROM procedurecode";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                r.moveToInsertRow();
                ok=true;
            } else {
                sql="SELECT * FROM procedurecode WHERE ID="+this.getId()+"";
                s=c.createStatement(java.sql.ResultSet.TYPE_SCROLL_SENSITIVE,java.sql.ResultSet.CONCUR_UPDATABLE);
                r=s.executeQuery(sql);
                ok=r.next();
            }
            if (ok) {
                r.updateString("CODE", this.getCode());
                r.updateString("DESCRIPTION",this.getDescription());
                r.updateString("ACCOUNT_ID", this.getAccountId());
                r.updateDouble("RATE",this.getRate());
                if (this.getId()==0) {
                    r.insertRow();
                } else {
                    r.updateRow();
                }
                return true;
            } else {
                return false; //not ok
            }
            
        } catch (Exception e) {
            this.setErrMessage(e.getMessage());
            return false;
        }
    }       
}
