/*
 * Attendance.java
 * 
 * Created on Oct 20, 2007, 3:18:47 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.dentalworx.controllers;

import com.dentalworx.view.PageView;
import com.ownx.util.WebController;
import com.ownx.webpages.Page;
import java.io.*;
import java.net.*;
import java.util.Date;

import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author nsdan2k
 */
public class Attendance extends HttpServlet {
   
    /** 
    * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        PageView view=new PageView(request,response);
        Page page=view.initialize("Attendance","global.css");
        

        WebController ctr=new WebController();
        model.Login login=(model.Login)request.getSession().getAttribute("login");
        if (login==null) {
            return;
        }
        login.setLastForm("attendance");
        request.getSession().setAttribute("login", login);
        if (!login.isAuthorized()) {
            ctr.forward("login", request, response);
            return;
        }        
        Date transDate;
        String selectDate=request.getParameter("selectDate");
        if (selectDate==null) {
            transDate=ctr.TODAY();
        } else {
            transDate=ctr.convertToDate(selectDate);
        }
        String cmd=request.getParameter("command");
        String entryId=request.getParameter("entryId");
        if (cmd!=null && entryId!=null) {
            if (cmd.equals("3")) {
                model.AttendanceItem detail=new model.AttendanceItem();
                detail.delete(ctr.convertToInt(entryId));
            }
        }           
// ********************************
// ** TITLE **            
// ********************************            
            page.text("Attendance", "titletext", "ledger.jpg", "", "", "210px", "125px", "300px", "35px", "3", "35px", "35px");
// ********************************
// ** MAIN SUB MENU **            
// ********************************            
            
           page.startForm("selection", "attendance", "post"); 
           page.startTable("stdgrid","200px","175px","468px","30px","4");
                page.startRow();
                    page.startCell("","1","1","");
                        page.text("Date:", "attribtext");
                        page.inputText("selectDate", ctr.convertDateToString(transDate), "81px");
                        page.inputSubmit("select", "Select");
                    page.endCell();
                    page.startCell("extralinkcell","1","1","");
                        //page.text("Settings", "extralinktext", "", "", "settings", "", "");
                        //page.space();
                        //page.space();
                        page.text("Create a New Entry", "extralinktext", "insert.jpg", "", "newattendanceitem?selectDate="+ctr.convertDateToString(transDate), "35px", "35px");
                    page.endCell();
                page.endRow();
            page.endTable(true);
            page.endForm();
            
            page.startTable("boxgrid","200px","230px","472px","300px","4");
                page.startRow();
                    page.startCell("","1","1","34%");
                        page.text("Doctor", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","33%");
                        page.text("Days", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","33%");
                        page.space();
                    page.endCell();
                page.endRow();
                
                String pg=request.getParameter("pg");
                if (pg==null) {
                    pg="1";
                }
                int bar=20;
                int size=20;
                int iPg=Integer.valueOf(pg).intValue();
                model.AttendanceItem detail=null;
                model.Attendance details=new model.Attendance();
                int count=details.fetch(transDate, login.getAccountId(),iPg, size);
                for (int i=0; i<details.size(); i++) {
                    detail=(model.AttendanceItem)details.get(i);
                    page.startRow();
                        page.startCell("","1","1","");
                            page.text(detail.getDoctor(), "");
                        page.endCell();
                        page.startCell("","1","1","");
                            page.text(""+detail.getNumDays(), "");
                        page.endCell();
                        page.startCell("extralinkcell", "1", "1", "");
                            page.text("Delete", "commandlinktext", "", "", "attendance?selectDate="+ctr.convertDateToString(transDate)+"&command=3&entryId="+detail.getId(), "", "");
                        page.endCell();                       
                    page.endRow();
                }
                page.startRow();
                    page.startCell("", "1", "3", "");
                        if (details.getSets()>1) {
                            for (int j=1; j<=details.getSets(); j++) {
                                if (iPg==j) {
                                    page.text(""+j,"pagingtext");
                                } else {
                                    page.text("<a href=\"attendance?pg="+j+"\">"+j+"</a>&nbsp;","extralinktext","","","","","");
                                }
                                if ((j % bar)==0) {
                                    page.println("<br/>");
                                }
                            }
                        }
                    page.endCell();
                page.endRow();                
            page.endTable(true);
            
        page.flush();
        view.finalize();
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
