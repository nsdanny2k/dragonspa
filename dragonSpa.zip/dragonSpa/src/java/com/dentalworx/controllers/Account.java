/*
 * Account.java
 * 
 * Created on Sep 5, 2007, 11:32:57 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.dentalworx.controllers;

import com.dentalworx.view.PageView;
import com.ownx.util.WebController;
import com.ownx.webpages.ListBox;
import com.ownx.webpages.ListBoxItem;
import com.ownx.webpages.Page;
import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author nsdan2k
 */
public class Account extends HttpServlet {
   
    /** 
    * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        PageView view=new PageView(request,response);

        WebController ctr=new WebController();
        model.Login login=(model.Login)request.getSession().getAttribute("login");
        if (login==null) {
            return;
        }
        login.setLastForm("account");
        request.getSession().setAttribute("login", login);
        if (!login.isAuthorized()) {
            ctr.forward("login", request, response);
            return;
        }      
        
        Page page;
        if (login.getAccountId().equals("system")) {
            page=view.initialize("Account Information","global.css","System");    
        } else {
            page=view.initialize("Account Information","global.css");
        }
        
        model.Account account=(model.Account)request.getSession().getAttribute("account");
        if (account==null) { account=new model.Account(); }

        String save=request.getParameter("save");
        String id=login.getAccountId();
        account.fetchMain(id);
        if ((save!=null)) {
            account.setFirstName(request.getParameter("firstName"));
            account.setMiddleName(request.getParameter("middleName"));
            account.setLastName(request.getParameter("lastName"));
            account.setGender(request.getParameter("gender"));
            account.setEmailAddress(request.getParameter("emailAddress"));
            account.setPhoneNumber(request.getParameter("phoneNumber"));
            account.setAddress1(request.getParameter("address1"));
            account.setAddress2(request.getParameter("address2"));
            account.setCity(request.getParameter("city"));
            account.setState(request.getParameter("state"));
            account.setCountry(request.getParameter("country"));
            account.setZip(request.getParameter("zip"));
            account.setPassword(request.getParameter("password"));
            //account.setNotation(request.getParameter("notation"));
            
           
        }
        //account.setAccountId(login.getAccountId());

        String errCode="";
        boolean bSaveSuccess2=false;
        boolean bSaveSuccess3=false;
        if ((save!=null)) {
            if (!(account.getFirstName().equals("")) && !(account.getLastName().equals(""))) {
                if (account.save()) {
                    login.refresh();
                    
                    String name2=request.getParameter("name2");
                    String pwd2=request.getParameter("pwd2");
                    model.Account account2=new model.Account();
                    if (name2.equals("")) {
                        if (account2.fetchSecondary(account.getAccountId())) {
                            account2.delete(account2.getPartyId());
                        }
                    } else {
                        if (account2.fetchSecondary(account.getAccountId())) {
                        }  else {
                            account2.add();
                        }
                        account2.setPartyId(name2);
                        account2.setPassword(pwd2);
                        account2.setAccountId(account.getAccountId());
                        account2.setAccountNumber(2);
                        bSaveSuccess2=account2.save();
                        if (!bSaveSuccess2) {
                            errCode=account2.getErrMessage();
                        }
                    }
                    
                    String name3=request.getParameter("name3");
                    String pwd3=request.getParameter("pwd3");
                    model.Account account3=new model.Account();
                    if (name3.equals("")) {
                        if (account3.fetchTertiary(account.getAccountId())) {
                            account3.delete(account3.getPartyId());
                        }
                    } else {
                        if (account3.fetchTertiary(account.getAccountId())) {
                        }  else {
                            account3.add();
                        }
                        account3.setPartyId(name3);
                        account3.setPassword(pwd3);
                        account3.setAccountId(account.getAccountId());
                        account2.setAccountNumber(3);
                        bSaveSuccess3=account3.save(); 
                        if (!bSaveSuccess3) {
                            if (errCode.equals("")) {
                                errCode=account3.getErrMessage();
                            } else {
                                errCode=errCode+";"+account3.getErrMessage();
                            }
                        }

                    }
                    if (errCode.equals("")) {
                        page.text("Account Information", "titletext", "", "", "", "210px", "125px", "300px", "35px", "3", "", "");
                        page.startTable("stdgrid","200px","210px","468px","30px","4");
                            page.startRow();
                                page.startCell("", "1", "1", "");
                                    page.text("Record successfully saved.","attribtext");
                                page.endCell();
                            page.endRow();
                            page.startRow();
                                page.startCell("", "1", "1", "");
                                    page.text("Return to record","","insert.jpg","","account","25px","25px");
                                    //page.text(account2.getErrMessage(),"");
                                page.endCell();
                            page.endRow();
                        page.endTable(true);
                        page.flush();
                        view.finalize();
                    }
                }
            }
        }
        request.getSession().setAttribute("account",account);        
// ********************************
// ** TITLE **            
// ********************************            
            page.text("Account Information", "titletext", "", "", "", "210px", "125px", "300px", "35px", "3", "", "");
       

            page.startForm("editaccount", "account", "post");
            //page.startTable("stdgrid","200px","220px","468px","30px","4");
            //    page.startRow();
            //        page.startCell("extralinkcell", "1", "1", "");
            //            page.text("Save", "attribtext", "", "", "", "30px", "30px");
            //            page.inputImage("save", "saveit.jpg", "");
                        //page.text("Ok", "attribtext", "", "", "", "30px", "30px");
                        //page.inputImage("ok", "check.jpg", "");
                        //page.text("Cancel", "attribtext", "", "", "", "30px", "30px");
                        //page.inputImage("cancel", "cross.jpg", "");
            //        page.endCell();
            //    page.endRow();
            //page.endTable(true);
        
            //page.startTable("boxgrid","200px","270px","472px","300px","4");
            page.startTable("boxgrid","200px","175px","472px","300px","4");
                page.startRow();
                    page.startCell("","1","1","25%");
                        page.text("First Name:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("firstName", ( account.getFirstName()==null)?"":account.getFirstName(), "130px");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text("Middle Name:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("middleName", ( account.getMiddleName()==null)?"":account.getMiddleName(), "130px");
                    page.endCell();
                page.endRow();  
                page.startRow();
                    page.startCell("","1","1","25%");
                        page.text("Last Name:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("lastName", ( account.getLastName()==null)?"":account.getLastName(), "130px");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text("Gender:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        ListBox listbox=new ListBox();
                        ListBoxItem item=new ListBoxItem();
                        item=new ListBoxItem("M","Male");
                        listbox.add(item);
                        item=new ListBoxItem("F","Female");
                        listbox.add(item);
                        page.inputSelect("gender", ( account.getGender()==null)?"M":account.getGender(), listbox,"135px");
                    page.endCell();
                page.endRow();
                page.startRow();
                    page.startCell("","1","1","25%");
                        page.text("Email :", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("emailAddress", (account.getEmailAddress()==null)?"":account.getEmailAddress(), "130px");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text("Phone#:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("phoneNumber", (account.getPhoneNumber()==null)?"":account.getPhoneNumber(), "130px");
                    page.endCell();
                page.endRow();
                page.startRow();
                    page.startCell("","1","1","25%");
                        page.text("Address :", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("address1", (account.getAddress1()==null)?"":account.getAddress1(), "130px");
                    page.endCell();
                    page.startCell("","1","2","50%");
                        page.inputText("address2", (account.getAddress2()==null)?"":account.getAddress2(), "97%");
                    page.endCell();
                page.endRow();
                page.startRow();
                    page.startCell("","1","1","25%");
                        page.text("City:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("city", (account.getCity()==null)?"":account.getCity(), "130px");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text("State / Province:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("state", (account.getState()==null)?"":account.getState(), "130px");
                    page.endCell();
                page.endRow();
                page.startRow();
                    page.startCell("","1","1","25%");
                        page.text("Country:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        listbox=new ListBox();
                        item=new ListBoxItem();
                        model.Country country;
                        model.Countries countries=new model.Countries();
                        countries.fetch();
                        for (int i=0; i<countries.size(); i++) {
                            country=(model.Country)countries.get(i);                        
                            item=new ListBoxItem(country.getCode(),country.getDescription());
                            listbox.add(item);
                        }
                        page.inputSelect("country", ( account.getCountry()==null)?"US":account.getCountry(), listbox,"135px");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text("", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text("","");
                    page.endCell();
                page.endRow();
                page.startRow();
                    page.startCell("","1","1","25%");
                        page.text("", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text("","");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text("Commission:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("zip", (account.getZip()==null)?"":account.getZip(), "130px");
                        page.inputHidden("command", "1");
                    page.endCell();
                page.endRow();
                page.startRow();
                    /*
                    page.startCell("","1","1","25%");
                        page.text("Notation System:", "attribtext");
                    page.endCell();
                    
                    page.startCell("","1","1","25%");
                        listbox=new ListBox();
                        item=new ListBoxItem();
                        item=new ListBoxItem("Universal","Universal Numbering System");
                        listbox.add(item);
                        item=new ListBoxItem("FDI","FDI Notation");
                        listbox.add(item);
                        page.inputSelect("notation", ( account.getNotation()==null)?"Universal":account.getNotation(), listbox,"135px");
                    page.endCell();
                     */
                    page.startCell("","1","1","25%");
                        page.space();
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.space();
                    page.endCell();
                page.endRow();

                page.startRow();
                    page.startCell("","1","4","100%");
                        page.space();
                    page.endCell();
                page.endRow();   

                page.startRow();
                    page.startCell("","1","4","100%");
                        page.text("Primary Account", "attribtext");
                    page.endCell();
                page.endRow();                 
                page.startRow();
                    page.startCell("","1","1","25%");
                        page.text("Name:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text(account.getPartyId(), "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text("Password:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("password",account.getPassword(), "130px");
                    page.endCell();
                page.endRow(); 
                
                String name2="";
                String pwd2="";
                model.Account account2=new model.Account();
                if (account2.fetchSecondary(account.getAccountId())) {
                    name2 = account2.getPartyId();
                    pwd2 = account2.getPassword();
                }
                page.startRow();
                    page.startCell("","1","4","100%");
                        page.text("Secondary Account", "attribtext");
                    page.endCell();
                page.endRow();                 
                page.startRow();
                    page.startCell("","1","1","25%");
                        page.text("Name:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("name2",name2, "130px");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text("Password:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("pwd2",pwd2, "130px");
                    page.endCell();
                page.endRow(); 
                
                String name3="";
                String pwd3="";
                model.Account account3=new model.Account();
                if (account3.fetchTertiary(account.getAccountId())) {
                    name3 = account3.getPartyId();
                    pwd3 = account3.getPassword();
                }
                page.startRow();
                    page.startCell("","1","4","100%");
                        page.text("Tertiary Account", "attribtext");
                    page.endCell();
                page.endRow();                 
                page.startRow();
                    page.startCell("","1","1","25%");
                        page.text("Name:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("name3",name3, "130px");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.text("Password:", "attribtext");
                    page.endCell();
                    page.startCell("","1","1","25%");
                        page.inputText("pwd3",pwd3, "130px");
                    page.endCell();
                page.endRow(); 
                if (!errCode.equals("")) {
                    page.startRow();
                        page.startCell("","1","4","100%");
                            page.text(errCode, "errortext");
                        page.endCell();
                    page.endRow();                
                }
                if (!account.getErrMessage().equals("")) {
                    page.startRow();
                        page.startCell("","1","4","100%");
                            page.text(account.getErrMessage(), "errortext");
                        page.endCell();
                    page.endRow();                
                }
                page.startRow();
                    page.startCell("extralinkcell", "1", "4", "");
                        //page.text("Save Record", "attribtext", "", "", "", "30px", "30px");
                        //page.inputImage("save", "saveit.jpg", "");
                        page.inputSubmit("save", "Save Record");
                    page.endCell();
                page.endRow();                
            page.endTable(true);
            page.endForm();
        
        page.flush();
        view.finalize();
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
